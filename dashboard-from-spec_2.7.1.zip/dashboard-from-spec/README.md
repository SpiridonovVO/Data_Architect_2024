# dashboard-from-spec — сборка дашбордов «по постановке»

Пакет для сборки дашбордов «по постановке»: **процесс, пайплайн, опросы, шаблоны**.
Доменно-агностичный: источник / сущности / метрики / методологии / BI — задаются под задачу.
Платформы ДИТ.Стат (Superset, Airflow, Postgres, GitLab) — пример реализации.

**Версия:** skill v2.4.9. **Проверки:** offline smoke + pytest regression suite; SQL-тесты требуют отдельную тестовую БД. Для prod требуется интеграционная приёмка на контуре заказчика.

## Состав

```
dashboard-from-spec/
├── skill/                 # ПРОЦЕСС (как работать) + ШАБЛОНЫ
│   ├── SKILL.md           # процесс + Gate-опросник (28 пунктов) + «Правило доработок»
│   ├── CHANGELOG.md       # история версий
│   └── templates/         # loader, dag, git_ops, dq_checks, promote, config.schema,
│                          # db_backup, freshness_check, постановка Confluence, RUNBOOK, estimate, реестр
├── pipeline/              # ИНСТРУМЕНТЫ (как собирать BI-дашборд)
│   ├── build_superset.py  # BI-адаптер Superset (декларативная сборка из config.json)
│   ├── render_html.py     # BI-адаптер HTML (тот же config.json → статический HTML)
│   ├── dashboard_state.py # last-known-good снапшоты (state/)
│   ├── revert.py          # быстрый откат дашборда
│   ├── superset_client.py, apply_dit_css.py, dit_stat_base.css
│   ├── config.schema.json, config.example.generic.json, data.example.json
│   ├── tests/             # smoke_test.py + фейковый superset_session_proxy (offline)
│   └── README.md
├── docs/                  # ДОКУМЕНТЫ
│   └── ОС_локальный_тест.md       # локальное тестирование
└── ИТОГ_пайплайн_v2.md     # итоговый отчёт по пайплайну
```

## Как пользоваться

1. **Процесс** — открыть `skill/SKILL.md`. Начать с **Gate-опросника** (блоки A–G) —
   задать вопросы заказчику, зафиксировать ответы в `config.json`.
2. **Сборка BI**:
   ```powershell
   # BI = Superset:
   python pipeline/build_superset.py --config config.json --dry-run
   python pipeline/build_superset.py --config config.json
   python pipeline/apply_dit_css.py <dashboard_id>
   # BI = HTML (альтернативный адаптер):
    python pipeline/render_html.py --config config.json --data data.json
   # Откат на last-known-good (снапшоты пишет build_superset в state/):
   python pipeline/revert.py --dash-id <dashboard_id> [--step 1] [--to prod]
    ```
    HTML остаётся статическим файлом. Чтобы KPI реагировали на фильтры, передайте исходные
    строки для KPI в `data.rows`; для графиков передавайте агрегированные строки.
3. **Данные/DAG** — шаблоны в `skill/templates/` (`loader.py`, `dag.py`, `git_ops.py`, `dq_checks.py`).

## ⚠ Изоляция от прод-контура
- `build_superset`/`apply_dit_css` **fail-closed**: без явного `SUPERSET_PROXY_DIR`
  не запускаются (прод-дефолт убран). Для тестов — фейковый прокси из `pipeline/tests/`.
- `promote.py`: среда (кроме prod) **обязана** задать свой `superset_proxy_dir`; если он
  или `superset_url` совпадают с прод-средой — прогон **отклоняется**. Прод-путь требует
  **`PROMOTE_ALLOW_PROD=1`**. Креды/`vars` среды инъецируются в шаги и билдер.
- CI: `.gitlab-ci.yml` — компиляция → pytest regression suite → dry-run → offline smoke. Дашборды не создаются.
- Тесты: штатный `smoke_test.py` и `pipeline/tests/qa/` работают offline. `test_postgres.py` запускайте только с отдельной тестовой `QA_POSTGRES_DSN`.
- Шаблон loader намеренно останавливается, пока `extract()` не адаптирован к реальному источнику; custom columns требуют соответствующего `DDL_ENV`.

## Ключевое
- Всё доменное — в `config.json` (метрики, сущности, источники), не в коде.
- Два BI-адаптера на одном `config.json` (Superset + HTML).
- Любая доработка предлагается пользователю **вопросом** (см. «Правило доработок»).

## Дальше (следующий этап)
Контракты адаптеров Source/Sink/BI/Orchestrator в коде; Secret Backend; CI; RLS;
staging-swap; инкремент выгрузки; data contracts. Подробно — `ИТОГ_пайплайн_v2.md`.
