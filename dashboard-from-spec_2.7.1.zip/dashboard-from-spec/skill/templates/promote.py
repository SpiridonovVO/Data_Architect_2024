#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""promote.py — промоушен пайплайна между средами (тест → прод).

Ставит среду из config.json (`env`), выполняет шаги, объявленные для этой среды,
затем собирает дашборд в Superset. Останавливается на первой ошибке.

  python promote.py --config config.json --to prod [--yes]

Конфиг, раздел environments:
  "env": "test",
  "environments": {
    "test": { "database_id": 1, "schema": "sales_metrics_test",
              "title": "[TEST] Продажи по продуктам",
              "superset_proxy_dir": "pipeline/tests",   # ОБЯЗАТЕЛЬНО для не-прод
              "superset_url": "https://bi-test.example",
              "vars": { "DB_HOST": "test-db" },          # инъекция в env шагов
              "steps": [ ["python","load_to_pg.py"] ] },
    "prod": { "database_id": 14, "schema": "sales_metrics",
              "superset_proxy_dir": "<путь к прод-прокси>",
              "title": "Продажи по продуктам",
              "steps": [ ["python","export_source.py"], ["python","load_to_pg.py"] ] }
  }

Изоляция: среда (кроме prod) ОБЯЗАНА задать свой `superset_proxy_dir`; если он
совпадает с прод-средой — прогон отклоняется. Прод требует PROMOTE_ALLOW_PROD=1.
"""
import argparse
import json
import os
import ntpath
import subprocess
import sys


ALLOW = set((os.environ.get("PROMOTE_ALLOW")
             or "python,python.exe,psql,pg_dump").split(","))


def find_builder(here):
    """Путь к build_superset.py: env, рядом, ../pipeline, ../../pipeline."""
    up1 = os.path.dirname(here)
    up2 = os.path.dirname(up1)
    cands = [os.environ.get("BUILD_SUPERSET"),
             os.path.join(here, "build_superset.py"),
             os.path.join(up1, "pipeline", "build_superset.py"),
             os.path.join(up2, "pipeline", "build_superset.py")]
    for p in cands:
        if p and os.path.exists(p):
            return p
    raise SystemExit("build_superset.py не найден; задайте BUILD_SUPERSET=путь")


def _normalize_url(value):
    if not value:
        return ""
    from urllib.parse import urlsplit, urlunsplit
    p = urlsplit(str(value).strip())
    if not p.scheme or not p.netloc:
        return str(value).strip().rstrip("/").casefold()
    return urlunsplit((p.scheme.casefold(), p.netloc.casefold(),
                       p.path.rstrip("/"), p.query, ""))


def _normalize_proxy(value):
    value = str(value or "").strip()
    if not value:
        return ""
    if ntpath.isabs(value) or os.path.isabs(value):
        return os.path.normcase(os.path.realpath(os.path.abspath(value)))
    return os.path.normcase(os.path.normpath(value))


def run(cmd, cwd=None, env=None):
    exe = os.path.basename(cmd[0])
    if exe not in ALLOW:
        raise SystemExit("команда '%s' не разрешена; добавьте в PROMOTE_ALLOW" % cmd[0])
    if (exe.startswith("python") and len(cmd) >= 3 and cmd[1] == "-c"
            and os.environ.get("PROMOTE_ALLOW_RCE") != "1"):
        raise SystemExit("'python -c' запрещён по умолчанию (RCE); "
                         "задайте PROMOTE_ALLOW_RCE=1, если это осознанно")
    print("  $ %s" % " ".join(cmd))
    r = subprocess.run(cmd, cwd=cwd, text=True, env=env)
    if r.returncode != 0:
        raise SystemExit("шаг провалился: %s (код %s)" % (cmd, r.returncode))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--to", required=True, choices=["test", "prod"])
    ap.add_argument("--yes", action="store_true", help="без подтверждения")
    ap.add_argument("--builder", help="путь к build_superset.py (иначе ищется сам)")
    ap.add_argument("--here", default=os.getcwd(),
                    help="рабочая папка для шагов")
    args = ap.parse_args()

    cfg = json.load(open(args.config, encoding="utf-8-sig"))
    envs = cfg.get("environments", {})
    target = envs.get(args.to)
    if not target:
        raise SystemExit("в конфиге нет среды '%s'" % args.to)

    if args.to == "prod" and os.environ.get("PROMOTE_ALLOW_PROD") != "1":
        raise SystemExit("прод-путь требует явного подтверждения: "
                         "задайте PROMOTE_ALLOW_PROD=1 (защита от случайного "
                         "прогона в реальный контур)")

    print("Промоушен: env=%s -> %s" % (cfg.get("env"), args.to))
    print("  schema=%s, database_id=%s, title=%s" % (
        target.get("schema"), target.get("database_id"), target.get("title")))
    if not args.yes:
        if input("Продолжить? [y/N] ").strip().lower() not in ("y", "yes", "да"):
            raise SystemExit("отменено")

    here = os.path.dirname(os.path.abspath(__file__))

    # --- Изоляция сред: определяем прокси/URL и запрещаем тест→прод ---
    prod = envs.get("prod") or {}
    if args.to != "prod" and not target.get("superset_proxy_dir"):
        raise SystemExit("среда '%s' обязана задать свой 'superset_proxy_dir' "
                         "(изоляция от прода)" % args.to)
    proxy = target.get("superset_proxy_dir") or os.environ.get("SUPERSET_PROXY_DIR")
    if not proxy:
        raise SystemExit("не задан SUPERSET_PROXY_DIR (ни в environments, ни в env) — "
                         "отказ, чтобы не уйти в реальный инстанс")
    url = target.get("superset_url") or os.environ.get("SUPERSET_URL")
    if args.to != "prod":
        if (prod.get("superset_proxy_dir") and
                _normalize_proxy(prod["superset_proxy_dir"]) == _normalize_proxy(proxy)):
            raise SystemExit("среда '%s' указывает на прод-прокси — отказ" % args.to)
        if (url and prod.get("superset_url") and
                _normalize_url(prod["superset_url"]) == _normalize_url(url)):
            raise SystemExit("среда '%s' указывает на прод-URL — отказ" % args.to)

    run_env = dict(os.environ)
    reserved = {"SUPERSET_PROXY_DIR", "SUPERSET_URL", "PROMOTE_ALLOW_PROD",
                "PATH", "PYTHONPATH", "PYTHONHOME"}
    for k, v in (target.get("vars") or {}).items():
        key = str(k)
        if key.upper() in reserved:
            raise SystemExit("переменная '%s' зарезервирована и не может "
                             "переопределяться через environments.vars" % key)
        run_env[key] = str(v)
    # The exact destinations validated above are the ones child processes use.
    run_env["SUPERSET_PROXY_DIR"] = proxy
    if url:
        run_env["SUPERSET_URL"] = url
    print("  proxy=%s url=%s" % (proxy, url or "(по умолчанию)"))

    # 1) промоушен-гейт: обязательные проверки до выката (DQ, свежесть и т.п.)
    for g in target.get("gate", []):
        run(g, cwd=args.here, env=run_env)

    # 2) шаги среды (используют инъецированные env-переменные)
    for step in target.get("steps", []):
        run(step, cwd=args.here, env=run_env)

    # 3) сборка дашборда на временном конфиге с env=target (реальный config не трогаем)
    tmp = args.config + ".run"
    run_cfg = dict(cfg, env=args.to)
    json.dump(run_cfg, open(tmp, "w", encoding="utf-8"), ensure_ascii=False,
              indent=2)
    try:
        run([sys.executable, args.builder or find_builder(here),
             "--config", tmp], cwd=args.here, env=run_env)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)

    # 4) только после успеха — зафиксировать среду атомарно
    new = args.config + ".new"
    json.dump(dict(cfg, env=args.to), open(new, "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    os.replace(new, args.config)
    print("Промоушен завершён: %s" % args.to)


if __name__ == "__main__":
    main()
