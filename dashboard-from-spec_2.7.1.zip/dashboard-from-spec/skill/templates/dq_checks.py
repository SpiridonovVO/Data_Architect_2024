#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""dq_checks.py — контроль качества данных (DQ-гейты) для витрин.

Запускается после загрузки (в DAG — шагом verify). При провале — DQError.
Проверки: not_empty, sum_eq, no_dupes, no_nulls, period_continuous (реальная).
Все идентификаторы валидируются (анти-инъекция).
"""
import logging
import re
from datetime import date, datetime

log = logging.getLogger("dq")

_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)?$")


class DQError(RuntimeError):
    pass


def _ident(name):
    if not isinstance(name, str) or not _IDENT.fullmatch(name):
        raise ValueError("недопустимый идентификатор: %r" % name)
    return name


def _ym(v):
    if hasattr(v, "year") and hasattr(v, "month"):
        if 1 <= v.month <= 12:
            return (v.year, v.month)
        raise ValueError("недопустимый месяц периода: %r" % (v,))
    text = str(v).strip()
    m = re.fullmatch(r"(\d{4})-(\d{2})", text)
    if m:
        year, month = int(m.group(1)), int(m.group(2))
        if 1 <= month <= 12:
            return year, month
        raise ValueError("недопустимый месяц периода: %r" % text)
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        return parsed.year, parsed.month
    except (ValueError, TypeError):
        try:
            parsed_date = date.fromisoformat(text)
            return parsed_date.year, parsed_date.month
        except (ValueError, TypeError):
            raise ValueError("недопустимый формат периода: %r" % text)


def _find_gaps(vals):
    vals = list(vals)
    if not vals:
        raise ValueError("нет значений периода для проверки непрерывности")
    pts = sorted({_ym(v) for v in vals})
    if not pts:
        return []
    ptset = set(pts)
    y, m = pts[0]
    last = pts[-1]
    gaps = []
    while (y, m) <= last:
        if (y, m) not in ptset:
            gaps.append("%04d-%02d" % (y, m))
        m += 1
        if m > 12:
            m, y = 1, y + 1
    return gaps


def run_checks(cn, checks):
    report = []
    for c in checks:
        kind = c["kind"]
        table = _ident(c["table"])
        with cn.cursor() as cur:
            if kind == "not_empty":
                cur.execute("SELECT count(*) FROM %s" % table)
                n = cur.fetchone()[0]
                report.append((table, "not_empty", n, n > 0))
            elif kind == "sum_eq":
                if "expected" not in c:
                    raise ValueError("sum_eq: нужен 'expected'")
                col = _ident(c["column"])
                cur.execute("SELECT coalesce(sum(%s),0) FROM %s" % (col, table))
                got = float(cur.fetchone()[0])
                exp = float(c["expected"])
                tol = abs(exp) * c.get("tolerance", 0.001)
                ok = abs(got - exp) <= tol
                report.append((table, "sum_eq(%s)" % col, got, ok))
            elif kind == "no_dupes":
                keys = c.get("keys") or []
                if not keys:
                    raise ValueError("no_dupes: пустой 'keys'")
                keys = ",".join(_ident(k) for k in keys)
                cur.execute("SELECT count(*) FROM (SELECT %s FROM %s "
                            "GROUP BY %s HAVING count(*)>1) t"
                            % (keys, table, keys))
                n = cur.fetchone()[0]
                report.append((table, "no_dupes(%s)" % keys, n, n == 0))
            elif kind == "no_nulls":
                cols = c.get("columns") or []
                if not cols:
                    raise ValueError("no_nulls: пустой 'columns'")
                cond = " OR ".join("%s IS NULL" % _ident(x) for x in cols)
                cur.execute("SELECT count(*) FROM %s WHERE %s" % (table, cond))
                n = cur.fetchone()[0]
                report.append((table, "no_nulls", n, n == 0))
            elif kind == "period_continuous":
                col = _ident(c["period"])
                cur.execute("SELECT DISTINCT %s FROM %s WHERE %s IS NOT NULL"
                            % (col, table, col))
                try:
                    gaps = _find_gaps([r[0] for r in cur.fetchall()])
                    report.append((table, "period_continuous",
                                   "пропусков %d %s" % (len(gaps), gaps[:6]),
                                   len(gaps) == 0))
                except ValueError as e:
                    report.append((table, "period_continuous", str(e), False))
            else:
                raise ValueError("неизвестная проверка: %s" % kind)

    fails = [r for r in report if not r[3]]
    for t, k, v, ok in report:
        log.info("%s %-28s %s %s", t, k, v, "OK" if ok else "FAIL")
    if fails:
        raise DQError("DQ провалено: %d: %s" % (len(fails), [f[1] for f in fails]))
    return report


if __name__ == "__main__":
    import json
    import os
    import psycopg2
    cfg_path = os.environ.get("DQ_CONFIG")
    checks = json.load(open(cfg_path, encoding="utf-8")) if cfg_path else []
    if not checks:
        raise SystemExit("Задайте DQ_CONFIG — JSON со списком проверок "
                         "(kind/table/…). Пример: [{\"kind\":\"not_empty\","
                         "\"table\":\"schema.tbl\"}]")
    cn = psycopg2.connect(host=os.environ["DB_HOST"],
                          port=int(os.environ.get("DB_PORT", "5432")),
                          dbname=os.environ.get("DB_NAME", "postgres"),
                          user=os.environ["DB_USER"],
                          password=os.environ["DB_PASS"],
                          sslmode=os.environ.get("DB_SSLMODE", "require"))
    try:
        run_checks(cn, checks)
        print("DQ OK")
    finally:
        cn.close()
