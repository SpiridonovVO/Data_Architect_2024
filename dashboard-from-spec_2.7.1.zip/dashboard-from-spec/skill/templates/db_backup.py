#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""db_backup.py — бэкап и восстановление схемы в Postgres (перед промоушеном).

  python db_backup.py --schema <schema> --out backup/
  python db_backup.py --restore backup/<schema>_20261005.sql --schema <schema>

Креды: DB_HOST/DB_PORT/DB_NAME/DB_USER/DB_PASS.
"""
import argparse
import os
import re
import subprocess
import time
import uuid

ENV = {**os.environ, "PGPASSWORD": os.environ.get("DB_PASS", "")}
HOST = os.environ.get("DB_HOST", "localhost")
PORT = os.environ.get("DB_PORT", "5432")
USER = os.environ.get("DB_USER", "postgres")
NAME = os.environ.get("DB_NAME", "postgres")


def base_cmd():
    return ["pg_dump", "-h", HOST, "-p", PORT, "-U", USER, "-d", NAME]


def backup(schema, out_dir):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", schema or ""):
        raise ValueError("недопустимое имя схемы: %r" % schema)
    os.makedirs(out_dir, exist_ok=True)
    fn = os.path.join(out_dir, "%s_%s_%s.sql" % (
        schema, time.strftime("%Y%m%d_%H%M%S"), uuid.uuid4().hex[:8]))
    tmp = fn + ".tmp"
    cmd = base_cmd() + ["-n", schema, "-f", tmp]
    print("бэкап схемы %s -> %s" % (schema, fn))
    try:
        subprocess.run(cmd, env=ENV, check=True)
        os.replace(tmp, fn)          # атомарно: недописанный дамп не станет «готовым»
    except Exception:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise
    print("готово:", fn)
    return fn


def restore(path, schema):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", schema or ""):
        raise SystemExit("недопустимое имя схемы: %r" % schema)
    # Fail closed: a plain-text pg_dump must explicitly create exactly the
    # requested schema. Scan the full file; comments in the header are not proof.
    found = set()
    pattern = re.compile(
        r'^\s*CREATE\s+SCHEMA\s+(?:IF\s+NOT\s+EXISTS\s+)?'
        r'(?:(?:"([A-Za-z_][A-Za-z0-9_]*)")|([A-Za-z_][A-Za-z0-9_]*))\s*;',
        re.IGNORECASE)
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            m = pattern.match(line)
            if m:
                found.add(m.group(1) or m.group(2))
    if found != {schema}:
        raise SystemExit("небезопасный/неподдерживаемый дамп: ожидалась только "
                         "схема '%s', обнаружены %s. Восстановление отменено"
                         % (schema, sorted(found)))
    print("восстановление %s в схему %s" % (path, schema))
    subprocess.run(["psql", "-h", HOST, "-p", PORT, "-U", USER, "-d", NAME,
                    "-v", "ON_ERROR_STOP=1", "-f", path], env=ENV, check=True)
    print("восстановлено")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--schema", required=True)
    ap.add_argument("--out", default="backup")
    ap.add_argument("--restore", help="файл .sql для восстановления")
    a = ap.parse_args()
    if a.restore:
        restore(a.restore, a.schema)
    else:
        backup(a.schema, a.out)
