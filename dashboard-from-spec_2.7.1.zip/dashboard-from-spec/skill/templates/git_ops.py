#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""git_ops.py — git-операции в GitLab (git.mos.ru) через REST API v4.

Создание ветки, коммит файлов, merge request — без локального git.
Токен/URL/проект — из окружения (в коде не хранятся).

  GITLAB_URL     = https://git.mos.ru
  GITLAB_TOKEN   = <personal/service token, scope api>
  GITLAB_PROJECT = <id или путь (кодируется автоматически), напр. "group/project">

Пример: см. функцию push_dag() внизу.
"""
import base64
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

BASE = os.environ.get("GITLAB_URL", "https://git.mos.ru").rstrip("/")
TOKEN = os.environ.get("GITLAB_TOKEN", "")
PROJECT = os.environ.get("GITLAB_PROJECT", "")


def _proj_id():
    """ID или путь проекта. Числовой id — как есть; путь кодируется один раз
    (если уже url-encoded — не кодируем повторно)."""
    p = PROJECT
    if p.isdigit() or "%2F" in p.upper():
        return p
    return urllib.parse.quote(p, safe="")


def _api(method, path, body=None):
    url = "%s/api/v4/projects/%s%s" % (BASE, _proj_id(), path)
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method,
                                 headers={"PRIVATE-TOKEN": TOKEN,
                                          "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, json.load(r)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")[:400]


def create_branch(branch, ref="main"):
    """Создать ветку от ref. Идемпотентно: 201 — создана, 400/409 — уже есть."""
    st, r = _api("POST", "/repository/branches",
                 {"branch": branch, "ref": ref})
    print("branch %s: %s" % (branch, st))
    if st in (200, 201):
        return True
    if st in (400, 409):
        msg = str(r).lower()
        if "exist" in msg or "already" in msg:
            return True
        raise SystemExit("не удалось создать ветку '%s': HTTP %s %s"
                         % (branch, st, str(r)[:150]))
    return False


def commit_files(branch, files, message, create_missing=True):
    """Закоммитить набор файлов в ветку.

    files: {"path/to/file.py": "content or bytes", ...}
    Использует единый commits API (несколько actions за один коммит).
    """
    actions = []
    for path, content in files.items():
        exists = _file_exists(branch, path)
        action = "update" if exists else "create"
        if not exists and not create_missing:
            continue
        if isinstance(content, bytes):
            content = content.decode("utf-8")
        actions.append({"action": action, "file_path": path,
                        "content": content})
    if not actions:
        print("нет изменений"); return False
    st, r = _api("POST", "/repository/commits",
                 {"branch": branch, "commit_message": message,
                  "actions": actions})
    print("commit %s: %s %s" % (branch, st, str(r)[:120]))
    return st in (200, 201)


def _file_exists(branch, path):
    p = "/repository/files/%s?ref=%s" % (urllib.parse.quote(path, safe=""),
                                         urllib.parse.quote(branch, safe=""))
    st, body = _api("GET", p)
    if st == 200:
        return True
    if st == 404:
        return False
    raise SystemExit("ошибка проверки файла '%s': GitLab HTTP %s %s"
                     % (path, st, str(body)[0:200]))


def create_mr(source, target, title, description="", remove_source=True):
    st, r = _api("POST", "/merge_requests", {
        "source_branch": source, "target_branch": target, "title": title,
        "description": description, "remove_source_branch": remove_source})
    if st in (200, 201):
        print("MR: %s" % r.get("web_url"))
        return r.get("web_url")
    print("MR err %s: %s" % (st, r))
    return None


def push_dag(dag_id, loader_src, dag_src):
    """Пример: закоммитить loader и DAG в новую ветку и открыть MR."""
    branch = "feature/%s" % dag_id
    base = os.environ.get("GITLAB_BASE", "main")
    if not create_branch(branch, ref=base):
        raise SystemExit("ветка '%s' не создана — MR не открываю" % branch)
    committed = commit_files(branch, {
        "dags/%s/loader.py" % dag_id: open(loader_src, encoding="utf-8").read(),
        "dags/%s/dag.py" % dag_id: open(dag_src, encoding="utf-8").read(),
    }, message="add DAG %s (loader + dag)" % dag_id)
    if not committed:
        raise SystemExit("коммит не выполнен (нет изменений или ошибка) — MR не открываю")
    return create_mr(branch, base, title="DAG %s" % dag_id,
                     description="Автосборка: loader + DAG для дашборда.")


if __name__ == "__main__":
    print("git_ops: BASE=%s PROJECT=%s token=%s" % (
        BASE, PROJECT or "(не задан)", "есть" if TOKEN else "нет"))
