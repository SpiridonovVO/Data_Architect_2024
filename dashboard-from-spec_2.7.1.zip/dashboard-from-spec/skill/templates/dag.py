#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Универсальный шаблон DAG (Airflow 3.2): загрузка по расписанию + DQ + verify.

Оркестратор — пример (Airflow). Портативный контракт: любой шедулер вызывает
loader.py/dq_checks.py с env-переменными. Имена/расписание — из конфигурации.

Секреты: приоритетно через Airflow **Connection** (`<prefix>_conn_id`), иначе —
Variables (с предупреждением). Пути к loader/dq_checks берутся внутри задач
(без запросов к metadata-DB на этапе парсинга DAG).

Адаптировать: schedule, VAR_PREFIX, имена Variables/Connection.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys

import pendulum
from airflow.decorators import dag, task
from airflow.models import Variable


def _var(name, default=None):
    return Variable.get("%s_%s" % (VAR_PREFIX, name), default_var=default)


def _ident(name):
    """Идентификатор SQL: только [A-Za-z_][A-Za-z0-9_]* (защита от инъекции)."""
    if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        raise ValueError("недопустимое имя схемы/таблицы: %r" % (name,))
    return name


def _creds():
    """Креды PostgreSQL: Connection (приоритет) или Variables. Ошибка, если пусто."""
    conn_id = _var("conn_id")
    if conn_id:
        from airflow.hooks.base import BaseHook
        c = BaseHook.get_connection(conn_id)
        extra = c.extra_dejson
        host, port = c.host, (c.port or 5432)
        user, pwd = c.login, c.password
        db = c.schema or extra.get("dbname") or "postgres"
        ssl = extra.get("sslmode", "require")
    else:
        host, port = _var("db_host"), _var("db_port", "5432")
        user, pwd = _var("db_user"), _var("db_pass")
        db, ssl = _var("db_name", "postgres"), _var("db_sslmode", "require")
    missing = [n for n, v in (("DB_HOST", host), ("DB_USER", user),
                              ("DB_PASS", pwd)) if not v]
    if missing:
        raise ValueError("не заданы креды %s — используйте Connection "
                         "(%s_conn_id) или Variables" % (missing, VAR_PREFIX))
    return {"DB_HOST": host, "DB_PORT": str(port), "DB_NAME": db,
            "DB_USER": user, "DB_PASS": pwd, "DB_SSLMODE": ssl}


def _db_env():
    return {**os.environ, **_creds(),
            "TARGET_SCHEMA": _var("target_schema", "project_metrics"),
            "TARGET_TABLE": _var("target_table", "fact_example")}


def _on_failure(context):
    ti = context.get("task_instance")
    print("DAG FAILED: %s.%s, try=%s, exception=%s"
          % (ti.dag_id if ti else "?", ti.task_id if ti else "?",
             ti.try_number if ti else "?", context.get("exception")))


VAR_PREFIX = Variable.get("dag_var_prefix", default_var="dash")
DAG_ID = Variable.get("dag_id", default_var="%s_load" % VAR_PREFIX)


@dag(
    dag_id=DAG_ID,
    schedule="0 3 * * *",
    start_date=pendulum.datetime(2026, 1, 1, tz="Europe/Moscow"),
    catchup=False,
    max_active_runs=1,
default_args={"retries": 2, "retry_delay": pendulum.duration(minutes=5),
                  "on_failure_callback": _on_failure,
                  # Airflow 3 removed legacy SLA alerts. This is only a task
                  # timeout; end-to-end SLA monitoring belongs to external alerts.
                  "execution_timeout": pendulum.duration(hours=2)},
    tags=["dashboard", "load"],
    doc_md="Загрузка данных для дашборда: loader → DQ → verify.",
)
def load_dag():
    @task
    def run_loader() -> str:
        loader = _var("loader_path", "/opt/airflow/dags/loader.py")
        env = _db_env()
        env["LOAD_METHOD"] = _var("load_method", "INC")
        res = subprocess.run([sys.executable, loader], env=env,
                             capture_output=True, text=True, check=True)
        print(res.stdout[-4000:])
        return "ok"

    @task
    def run_dq() -> None:
        cfg = _var("dq_config")
        if not cfg:
            required = _var("dq_required", "true").strip().lower()
            if required not in ("0", "false", "no", "off"):
                raise ValueError("DQ_CONFIG не задан, а dq_required=true; "
                                 "DQ-гейт не может быть пропущен")
            print("DQ_CONFIG не задан; проверка пропущена по dq_required=false")
            return
        checks = _var("dq_checks_path", "/opt/airflow/dags/dq_checks.py")
        env = {**_db_env(), "DQ_CONFIG": cfg}
        res = subprocess.run([sys.executable, checks], env=env,
                             capture_output=True, text=True, check=True)
        print(res.stdout[-4000:])

    @task
    def verify() -> None:
        import psycopg2
        cr = _creds()
        cn = psycopg2.connect(host=cr["DB_HOST"], port=int(cr["DB_PORT"]),
                              dbname=cr["DB_NAME"], user=cr["DB_USER"],
                              password=cr["DB_PASS"], sslmode=cr["DB_SSLMODE"])
        try:
            with cn.cursor() as cur:
                cur.execute("SELECT count(*) FROM %s.%s"
                            % (_ident(_var("target_schema", "project_metrics")),
                               _ident(_var("target_table", "fact_example"))))
                n = cur.fetchone()[0]
        finally:
            cn.close()
        if n == 0:
            raise ValueError("целевая таблица пуста")
        print("строк в приёмнике:", n)

    run_loader() >> run_dq() >> verify()


load_dag()
