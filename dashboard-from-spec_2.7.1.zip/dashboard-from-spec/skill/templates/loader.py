#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Универсальный шаблон скрипта-загрузчика (ИСТОЧНИК → БД). Метод — из LOAD_METHOD.

Методы: FULL, INC (по умолчанию), DELTA, APPEND, UPSERT, PARTREPL, SNAPSHOT.
Свойства: создаёт схему/таблицы при отсутствии, идемпотентен, resumable (курсор в
<schema>.load_state), retry/backoff, секреты в env. Источник и колонки — из конфига/env
(не зашиты под домен).

Env: DB_HOST/PORT/NAME/USER/PASS/SSLMODE, TARGET_SCHEMA, TARGET_TABLE,
     COLUMNS (default "id,updated_at,payload"), KEY_COLS, CURSOR_COL,
     PARTITION (для PARTREPL), ALLOW_EMPTY_FULL (разрешить TRUNCATE при пустом).
Адаптировать: extract() и (при необходимости) DDL_ENV.
"""
import os
import re
import time
import logging

import psycopg2
from psycopg2 import sql
from psycopg2.extras import execute_values

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("loader")

_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _ident(name):
    if not isinstance(name, str) or not _IDENT.fullmatch(name):
        raise ValueError("недопустимый идентификатор: %r" % name)
    return name


LOAD_METHOD = os.environ.get("LOAD_METHOD", "INC").upper()
VALID_METHODS = {"FULL", "INC", "DELTA", "APPEND", "UPSERT", "PARTREPL", "SNAPSHOT"}
SCHEMA = _ident(os.environ.get("TARGET_SCHEMA", "project_metrics"))
TABLE = _ident(os.environ.get("TARGET_TABLE", "fact_example"))
COLUMNS = [_ident(c.strip()) for c in os.environ.get("COLUMNS",
           "id,updated_at,payload").split(",") if c.strip()]
KEY_COLS = [_ident(k.strip()) for k in os.environ.get("KEY_COLS", "id").split(",")
            if k.strip()]
CURSOR_COL = _ident(os.environ.get("CURSOR_COL", "updated_at"))
BATCH = int(os.environ.get("BATCH", "10000"))
MAX_RETRIES = int(os.environ.get("MAX_RETRIES", "5"))
if BATCH < 1:
    raise SystemExit("BATCH должен быть >= 1")
if MAX_RETRIES < 1:
    raise SystemExit("MAX_RETRIES должен быть >= 1")
if len(COLUMNS) != len(set(COLUMNS)):
    raise SystemExit("COLUMNS содержит повторяющиеся имена")
if len(KEY_COLS) != len(set(KEY_COLS)):
    raise SystemExit("KEY_COLS содержит повторяющиеся имена")

_missing_keys = [k for k in KEY_COLS if k not in COLUMNS]
if not KEY_COLS or _missing_keys:
    raise SystemExit("KEY_COLS %s должны входить в COLUMNS %s"
                     % (KEY_COLS or "(пусто)", COLUMNS))

# DDL можно переопределить целиком (env DDL_ENV = путь к .sql)
DDL = f"""
CREATE SCHEMA IF NOT EXISTS {SCHEMA};
CREATE TABLE IF NOT EXISTS {SCHEMA}.{TABLE} (
    id             text PRIMARY KEY,
    updated_at     timestamptz,
    payload        jsonb,
    partition_key  text,
    snapshot_date  date,
    loaded_at      timestamptz DEFAULT now()
);
CREATE TABLE IF NOT EXISTS {SCHEMA}.load_state (
    target text PRIMARY KEY, cursor text, updated_at timestamptz DEFAULT now()
);
"""


def connect():
    return psycopg2.connect(
        host=os.environ["DB_HOST"], port=int(os.environ.get("DB_PORT", "5432")),
        dbname=os.environ.get("DB_NAME", "postgres"),
        user=os.environ["DB_USER"], password=os.environ["DB_PASS"],
        sslmode=os.environ.get("DB_SSLMODE", "require"), connect_timeout=20)


def retry(fn, *a, **k):
    if MAX_RETRIES < 1:
        raise ValueError("MAX_RETRIES должен быть >= 1")
    for i in range(MAX_RETRIES):
        try:
            return fn(*a, **k)
        except Exception as e:
            if i == MAX_RETRIES - 1:
                raise
            wait = min(2 ** i, 30)
            log.warning("попытка %d/%d не удалась (%s), ждём %ds",
                        i + 1, MAX_RETRIES, e, wait)
            time.sleep(wait)


def extract(cursor=None):
    """Реализуйте извлечение из источника и верните (rows, new_cursor)."""
    raise NotImplementedError(
        "адаптируйте extract() к источнику данных; пустая заглушка запрещена")


def ensure_schema_table(cn):
    ddl_env = os.environ.get("DDL_ENV")
    text = open(ddl_env, encoding="utf-8").read() if ddl_env and \
        os.path.exists(ddl_env) else DDL
    with cn.cursor() as cur:
        cur.execute(text)
    cn.commit()


def read_cursor(cn):
    if LOAD_METHOD not in ("INC", "DELTA"):
        return None
    with cn.cursor() as cur:
        cur.execute(
            sql.SQL("SELECT cursor FROM {}.load_state WHERE target=%s")
            .format(sql.Identifier(SCHEMA)), (TABLE,))
        row = cur.fetchone()
        return row[0] if row else None


def save_cursor(cn, cursor, commit=True):
    if cursor is None:
        return
    with cn.cursor() as cur:
        cur.execute(
            sql.SQL("INSERT INTO {}.load_state(target, cursor, updated_at) "
                    "VALUES (%s, %s, now()) ON CONFLICT (target) DO UPDATE "
                    "SET cursor=EXCLUDED.cursor, updated_at=now()")
            .format(sql.Identifier(SCHEMA)), (TABLE, str(cursor)))
    if commit:
        cn.commit()


def _upsert_sql(tgt, ext=()):
    cols = COLUMNS + list(ext)
    upd_cols = [c for c in cols if c not in KEY_COLS]
    if not upd_cols:
        return ("INSERT INTO %s (%s) VALUES %%s ON CONFLICT (%s) DO NOTHING"
                % (tgt, ",".join(cols), ",".join(KEY_COLS)))
    set_parts = ["%s=EXCLUDED.%s" % (c, c) for c in upd_cols]
    set_parts.append("loaded_at=now()")
    return ("INSERT INTO %s (%s) VALUES %%s ON CONFLICT (%s) DO UPDATE SET %s"
            % (tgt, ",".join(cols), ",".join(KEY_COLS), ",".join(set_parts)))


def load(cn, rows, commit=True):
    if LOAD_METHOD not in VALID_METHODS:
        raise ValueError("LOAD_METHOD=%r не поддержан ({%s})"
                         % (LOAD_METHOD, ", ".join(sorted(VALID_METHODS))))
    tgt = "%s.%s" % (SCHEMA, TABLE)

    if not rows:
        if LOAD_METHOD == "FULL" and os.environ.get("ALLOW_EMPTY_FULL") == "1":
            with cn.cursor() as cur:
                cur.execute("TRUNCATE %s" % tgt)
            if commit:
                cn.commit()
            log.info("FULL: источник пуст, разрешено — таблица очищена")
        else:
            log.info("нечего загружать (пустой источник)")
        return 0

    with cn.cursor() as cur:
        if LOAD_METHOD == "FULL":
            cur.execute("TRUNCATE %s" % tgt)
            execute_values(cur, "INSERT INTO %s (%s) VALUES %%s"
                           % (tgt, ",".join(COLUMNS)), rows, page_size=BATCH)
        elif LOAD_METHOD in ("INC", "UPSERT"):
            execute_values(cur, _upsert_sql(tgt), rows, page_size=BATCH)
        elif LOAD_METHOD == "DELTA":
            log.warning("DELTA применяется как UPSERT: удаления не отслеживаются")
            execute_values(cur, _upsert_sql(tgt), rows, page_size=BATCH)
        elif LOAD_METHOD == "APPEND":
            execute_values(cur, "INSERT INTO %s (%s) VALUES %%s"
                           % (tgt, ",".join(COLUMNS)), rows, page_size=BATCH)
        elif LOAD_METHOD == "PARTREPL":
            part = os.environ.get("PARTITION")
            if not part:
                raise ValueError("PARTREPL: задайте PARTITION")
            if "partition_key" not in COLUMNS:
                raise ValueError("PARTREPL: partition_key обязана входить в COLUMNS")
            part_idx = COLUMNS.index("partition_key")
            if any(len(row) != len(COLUMNS) or str(row[part_idx]) != part
                   for row in rows):
                raise ValueError("PARTREPL: каждая строка должна соответствовать "
                                 "PARTITION и COLUMNS")
            cur.execute("DELETE FROM %s WHERE partition_key=%%s" % tgt, (part,))
            execute_values(cur, "INSERT INTO %s (%s) VALUES %%s"
                           % (tgt, ",".join(COLUMNS)), rows, page_size=BATCH)
        elif LOAD_METHOD == "SNAPSHOT":
            if "snapshot_date" not in KEY_COLS:
                log.warning("SNAPSHOT: 'snapshot_date' не в KEY_COLS — история "
                            "перезаписывается (текущее состояние). Для истории: "
                            "KEY_COLS=id,snapshot_date + DDL с составным ключом")
            snap_date = time.strftime("%Y-%m-%d")
            if "snapshot_date" in COLUMNS:
                idx = COLUMNS.index("snapshot_date")
                snap_rows = [tuple(r[:idx]) + (snap_date,) + tuple(r[idx + 1:])
                             for r in rows]
                ext = ()
            else:
                snap_rows = [tuple(r) + (snap_date,) for r in rows]
                ext = ("snapshot_date",)
            execute_values(cur, _upsert_sql(tgt, ext), snap_rows,
                           page_size=BATCH)
    if commit:
        cn.commit()
    log.info("загружено строк: %d (метод %s)", len(rows), LOAD_METHOD)
    return len(rows)


def main():
    cn = connect()
    try:
        ensure_schema_table(cn)
        cursor = read_cursor(cn)
        rows, new_cursor = retry(extract, cursor)
        n = load(cn, rows, commit=False)
        save_cursor(cn, new_cursor, commit=False)
        cn.commit()
    except Exception:
        cn.rollback()
        raise
    finally:
        cn.close()
    log.info("готово: %d строк", n)


if __name__ == "__main__":
    main()
