#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""freshness_check.py — мониторинг свежести витрины (данные обновляются вовремя?).

Проверяет максимальную дату загрузки/период в целевой таблице и сравнивает с
ожидаемой свежестью. Полезно запускать отдельным шагом DAG или по расписанию.

  python freshness_check.py --table <schema>.load_state --col updated_at \
      --max-age-hours 26

Креды: DB_HOST/DB_PORT/DB_NAME/DB_USER/DB_PASS.
При устаревании — ненулевой код возврата (для алерта).
"""
import argparse
import os
import re
import sys
from datetime import datetime, timezone

import psycopg2

_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)?$")


def _ident(name):
    if not _IDENT.match(name or ""):
        raise SystemExit("недопустимый идентификатор: %r" % name)
    return name


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--table", required=True)
    ap.add_argument("--col", default="updated_at")
    ap.add_argument("--max-age-hours", type=float, default=26.0)
    a = ap.parse_args()
    table, col = _ident(a.table), _ident(a.col)

    cn = psycopg2.connect(
        host=os.environ["DB_HOST"], port=int(os.environ.get("DB_PORT", "5432")),
        dbname=os.environ.get("DB_NAME", "postgres"),
        user=os.environ["DB_USER"], password=os.environ["DB_PASS"],
        sslmode=os.environ.get("DB_SSLMODE", "require"), connect_timeout=20)
    try:
        with cn.cursor() as cur:
            cur.execute("SELECT max(%s) FROM %s" % (col, table))
            last = cur.fetchone()[0]
    finally:
        cn.close()

    if last is None:
        print("FRESHNESS FAIL: нет данных в %s" % table)
        sys.exit(1)
    if not isinstance(last, datetime):
        last = datetime(last.year, last.month, last.day)
    if last.tzinfo is None:
        last = last.replace(tzinfo=timezone.utc)
    age = (datetime.now(timezone.utc) - last.astimezone(timezone.utc)
           ).total_seconds() / 3600.0
    status = "OK" if age <= a.max_age_hours else "STALE"
    print("FRESHNESS %s: последняя запись %s, возраст %.1f ч (порог %.1f ч)"
          % (status, last, age, a.max_age_hours))
    sys.exit(0 if status == "OK" else 2)


if __name__ == "__main__":
    main()
