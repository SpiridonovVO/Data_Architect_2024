#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""revert.py — быстрый откат дашборда на last-known-good конфиг.

Использует снапшоты из `state/` (их пишет build_superset после успешной сборки):
перезаписывает дашборд конфигом из выбранного снапшота и запускает сборку.

  python revert.py --dash-id <dashboard_id> [--step 1] [--to test] [--yes]

  --step N — отступить на N снапшотов назад (1 = предыдущий).
  --to prod — откат в прод (требует PROMOTE_ALLOW_PROD=1).
  --out FILE — куда писать временный конфиг отката.

Изоляция: build_superset требует SUPERSET_PROXY_DIR (fail-closed), прод требует
PROMOTE_ALLOW_PROD=1 — те же гарды, что и при обычной сборке.
"""
import argparse
import json
import os
import subprocess
import sys
import time

import dashboard_state


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dash-id", required=True, type=int)
    ap.add_argument("--step", type=int, default=1)
    ap.add_argument("--to", choices=["test", "prod"], default="test")
    ap.add_argument("--yes", action="store_true")
    ap.add_argument("--out")
    a = ap.parse_args()

    if a.to == "prod" and os.environ.get("PROMOTE_ALLOW_PROD") != "1":
        raise SystemExit("прод-откат требует PROMOTE_ALLOW_PROD=1")

    here = os.path.dirname(os.path.abspath(__file__))

    snaps = dashboard_state.list_snapshots(a.dash_id, here)
    if not snaps:
        raise SystemExit("нет снапшотов для dash_id=%s (была ли сборка?)" % a.dash_id)
    if a.step < 1:
        raise SystemExit("--step должен быть >= 1 (1 = предыдущий снапшот)")
    # The latest snapshot is the current state, so step=1 targets the one before it.
    idx = len(snaps) - 1 - a.step
    if idx < 0:
        raise SystemExit("нет предыдущего снапшота для шага %d (всего %d)"
                         % (a.step, len(snaps)))
    target = snaps[idx]
    print("откат dash_id=%s на снапшот от %s (шаг %d, всего %d)"
          % (a.dash_id, target["ts"], a.step, len(snaps)))
    print("  title: %s" % target["config"].get("dashboard", {}).get("title"))
    if not a.yes:
        if input("Продолжить? [y/N] ").strip().lower() not in ("y", "yes", "да"):
            raise SystemExit("отменено")

    cfg = dict(target["config"])
    envs = cfg.get("environments") or {}
    run_env = dict(os.environ)
    if envs:
        env_cfg = envs.get(a.to)
        if not isinstance(env_cfg, dict):
            raise SystemExit("в снапшоте отсутствует конфигурация среды '%s'" % a.to)
        cfg["env"] = a.to
        proxy = env_cfg.get("superset_proxy_dir")
        if not proxy:
            raise SystemExit("среда '%s' не задаёт superset_proxy_dir" % a.to)
        prod_cfg = envs.get("prod") or {}
        if a.to != "prod":
            p1, p2 = os.path.normcase(os.path.realpath(os.path.abspath(proxy))), \
                     os.path.normcase(os.path.realpath(os.path.abspath(
                         prod_cfg.get("superset_proxy_dir", ""))))
            if prod_cfg.get("superset_proxy_dir") and p1 == p2:
                raise SystemExit("среда '%s' совпадает с прод-прокси" % a.to)
            url = env_cfg.get("superset_url")
            prod_url = prod_cfg.get("superset_url")
            if url and prod_url and url.rstrip("/").casefold() == prod_url.rstrip("/").casefold():
                raise SystemExit("среда '%s' совпадает с прод-URL" % a.to)
        run_env["SUPERSET_PROXY_DIR"] = proxy
        if env_cfg.get("superset_url"):
            run_env["SUPERSET_URL"] = env_cfg["superset_url"]
        reserved = {"SUPERSET_PROXY_DIR", "SUPERSET_URL", "PROMOTE_ALLOW_PROD",
                    "PATH", "PYTHONPATH", "PYTHONHOME"}
        for key, value in (env_cfg.get("vars") or {}).items():
            if str(key).upper() in reserved:
                raise SystemExit("переменная '%s' зарезервирована" % key)
            run_env[str(key)] = str(value)
    elif a.to == "prod":
        raise SystemExit("прод-откат требует environments.prod и явный прокси")

    cfg["dashboard_id"] = a.dash_id

    out = a.out or os.path.join(os.getcwd(), "revert_d%s.json" % a.dash_id)
    tmp_out = out + ".tmp"
    try:
        with open(tmp_out, "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, ensure_ascii=False, indent=2)
        os.replace(tmp_out, out)
    finally:
        if os.path.exists(tmp_out):
            os.remove(tmp_out)

    builder = os.path.join(here, "build_superset.py")
    print("сборка из %s …" % out)
    r = subprocess.run([sys.executable, builder, "--config", out],
                       env=run_env, text=True)
    if r.returncode != 0:
        raise SystemExit("откат провалился (код %d)" % r.returncode)
    print("откат завершён: dash_id=%s -> %s" % (a.dash_id, target["ts"]))


if __name__ == "__main__":
    main()
