#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""render_html.py — альтернативный BI-адаптер: config.json → самодостаточный HTML-дашборд.

Второй (после Superset) адаптер BI. Доказывает переносимость ядра: тот же config.json
рендерится и в Superset (build_superset.py), и в статический HTML.

    python render_html.py --config config.json [--data data.json] [--out out/board.html]

data.json (опционально) — данные для наполнения:
  {
    "values": { "<chart_key>": 123.0 },              # для плашек big_number
    "rows":   { "<chart_key>": [ { "<колонка>": ... } ] }   # для графиков/таблиц
  }
Без --data рисуется каркас (структура, подписи, заглушки).
"""
import argparse
import html
import json
import os
import re

DIT = ("--accent:#0062E1;--soft:#E0E9F8;--canvas:#EEEFF3;"
       "--text:#13151A;--border:#EAECEF;--muted:#5D6570;--radius:16px;")


def esc(s):
    return html.escape(str(s if s is not None else ""))


def md(text):
    if not text:
        return ""
    out = []
    for line in text.replace("\r\n", "\n").split("\n"):
        if line.startswith("### "):
            out.append("<h3>%s</h3>" % esc(line[4:]))
        elif line.startswith("## "):
            out.append("<h2>%s</h2>" % esc(line[3:]))
        elif line.startswith("# "):
            out.append("<h1>%s</h1>" % esc(line[2:]))
        elif line.strip():
            out.append("<p>%s</p>" % esc(line).replace("**", ""))
    return '<div class="md">%s</div>' % "".join(out)


def _fattr(row, fcols):
    if not fcols:
        return ""
    d = {c: row.get(c) for c in fcols}
    return ' data-f="%s"' % esc(json.dumps(d, ensure_ascii=False, default=str))


def bars(rows, xcol, metric_keys, fcols=()):
    if not rows:
        return '<div class="ph">нет данных</div>'

    if not metric_keys:
        raise ValueError("для графика не заданы метрики")
    for r in rows:
        missing = [k for k in metric_keys if k not in r]
        if missing:
            raise ValueError("в данных графика отсутствуют метрики %s" % missing)
    vals = [(str(r.get(xcol, "")),
             [float(r.get(k) or 0) for k in metric_keys], r) for r in rows]
    maxima = [max((vs[i] for _, vs, _ in vals), default=1) or 1
              for i in range(len(metric_keys))]
    colors = ["#0062E1", "#E4572E", "#2E8B57", "#8A4FFF", "#D39B00"]
    items = []
    for label, values, row in vals:
        for i, value in enumerate(values):
            items.append(
                '<div class="bar" data-series="%s" style="--series-color:%s"%s><span class="lbl">%s</span>'
                '<span class="track"><i style="width:%.1f%%"></i></span>'
                '<span class="val">%s</span></div>'
                % (esc(metric_keys[i]), colors[i % len(colors)],
                   _fattr(row, fcols), esc(label),
                   100.0 * value / maxima[i],
                   format(int(value), ",") if value == int(value) else value))
    legend = ('<div class="series-legend">%s</div>' % "".join(
        '<span><i style="background:%s"></i>%s</span>'
        % (colors[i % len(colors)], esc(name))
        for i, name in enumerate(metric_keys))) if len(metric_keys) > 1 else ""
    return '<div class="bars">%s</div>%s' % ("".join(items), legend)


def line_chart(rows, xcol, metric_keys, fcols=()):
    if not rows:
        return '<div class="ph">нет данных</div>'
    if not metric_keys:
        raise ValueError("для линейного графика не заданы метрики")
    for r in rows:
        missing = [k for k in metric_keys if k not in r]
        if missing:
            raise ValueError("в данных графика отсутствуют метрики %s" % missing)
    width, height, pad = 640, 220, 24
    all_values = [float(r.get(k) or 0) for r in rows for k in metric_keys]
    lo, hi = min(all_values), max(all_values)
    span = hi - lo or 1
    xstep = (width - 2 * pad) / max(1, len(rows) - 1)
    colors = ["#0062E1", "#E4572E", "#2E8B57", "#8A4FFF", "#D39B00"]
    parts = ['<svg class="line-chart" viewBox="0 0 %d %d" role="img">'
             % (width, height)]
    for i, key in enumerate(metric_keys):
        pts = []
        for j, row in enumerate(rows):
            x = pad + j * xstep
            y = height - pad - (float(row.get(key) or 0) - lo) / span * (height - 2 * pad)
            pts.append("%.1f,%.1f" % (x, y))
        color = colors[i % len(colors)]
        parts.append('<polyline data-line-series="%s" fill="none" stroke="%s" stroke-width="3" points="%s"/>'
                     % (esc(key), color, " ".join(pts)))
        for j, row in enumerate(rows):
            x = pad + j * xstep
            y = height - pad - (float(row.get(key) or 0) - lo) / span * (height - 2 * pad)
            parts.append('<circle data-line-series="%s" data-f="%s" cx="%.1f" cy="%.1f" r="4" fill="%s"><title>%s: %s</title></circle>'
                         % (esc(key), esc(json.dumps({c: row.get(c) for c in fcols}, ensure_ascii=False, default=str)),
                            x, y, color, esc(key), esc(row[key])))
    parts.append('</svg><div class="line-legend">%s</div>' % "".join(
        '<span>%s</span>' % esc(k) for k in metric_keys))
    return "".join(parts)


def table(rows, cols, fcols=()):
    if not rows:
        return '<div class="ph">нет данных</div>'
    head = "".join("<th>%s</th>" % esc(c[0] if isinstance(c, tuple) else c)
                   for c in cols)
    parts = []
    for r in rows:
        parts.append("<tr%s>%s</tr>" % (
            _fattr(r, fcols),
            "".join("<td>%s</td>" % esc(r.get(c[0], r.get(c[1], "—"))
                                      if isinstance(c, tuple) else r.get(c, "—"))
                    for c in cols)))
    return '<table><thead><tr>%s</tr></thead><tbody>%s</tbody></table>' % (
        head, "".join(parts))


def widget(chart, data, fcols=()):
    key, viz = chart["key"], chart["viz"]
    name = chart.get("name", key)
    values = (data.get("values") or {})
    rows = (data.get("rows") or {}).get(key, [])
    if viz in ("big_number", "big_number_total"):
        v = values.get(key, "—")
        m = chart.get("metric") or {}
        raw = (' data-rows="%s" data-fcols="%s" data-agg="%s" data-col="%s"'
               % (esc(json.dumps(rows, ensure_ascii=False, default=str)),
                  esc(json.dumps(list(fcols), ensure_ascii=False)),
                  esc(m.get("agg", "SUM")), esc(m.get("col", "")))) if rows else ""
        body = '<div class="big" data-kpi="%s"%s>%s</div>' % (
            esc(key), raw, esc(v))
    elif viz == "echarts_timeseries_bar":
        metrics = chart.get("metrics") or []
        keys = [m.get("label") or m.get("col") for m in metrics]
        body = bars(rows, chart.get("x_axis", ""), keys, fcols)
    elif viz == "echarts_timeseries_line":
        metrics = chart.get("metrics") or []
        keys = [m.get("label") or m.get("col") for m in metrics]
        body = line_chart(rows, chart.get("x_axis", ""), keys, fcols)
    elif viz == "table":
        cols = [(c, c) for c in (chart.get("groupby") or [])] + [
            (m.get("label") or m.get("col"), m.get("col"))
            for m in chart.get("metrics", [])]
        body = table(rows, cols, fcols)
    elif viz == "bubble_v2":
        body = bubble_chart(rows, chart, fcols)
    else:
        body = '<div class="ph">%s</div>' % esc(viz)
    return '<div class="card"><div class="ct">%s</div>%s</div>' % (esc(name), body)


def bubble_chart(rows, chart, fcols=()):
    if not rows:
        return '<div class="ph">нет данных</div>'
    fields = {axis: (chart.get(axis) or {}).get("label") or
              (chart.get(axis) or {}).get("col") for axis in ("x", "y", "size")}
    for row in rows:
        missing = [field for field in fields.values() if field not in row]
        if missing:
            raise ValueError("в данных scatter отсутствуют поля %s" % missing)
    xs = [float(row[fields["x"]]) for row in rows]
    ys = [float(row[fields["y"]]) for row in rows]
    ss = [max(0.0, float(row[fields["size"]])) for row in rows]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)
    smax = max(ss) or 1
    width, height, pad = 640, 300, 28
    parts = ['<svg class="bubble-chart" viewBox="0 0 %d %d" role="img">'
             % (width, height)]
    for row, xval, yval, size in zip(rows, xs, ys, ss):
        x = pad + (xval - xmin) / (xmax - xmin or 1) * (width - 2 * pad)
        y = height - pad - (yval - ymin) / (ymax - ymin or 1) * (height - 2 * pad)
        radius = 5 + 15 * (size / smax) ** 0.5
        title = "%s: %s, %s: %s" % (fields["x"], xval, fields["y"], yval)
        parts.append('<circle cx="%.1f" cy="%.1f" r="%.1f" fill="#0062E1" fill-opacity=".55"%s><title>%s</title></circle>'
                     % (x, y, radius, _fattr(row, fcols), esc(title)))
    parts.append('</svg>')
    return "".join(parts)


def fcol_map(cfg):
    """chart_key -> [колонки фильтров, применимые к датасету чарта]."""
    out = {}
    for c in cfg.get("charts", []):
        cols = [f["column"] for f in cfg.get("filters", [])
                if c.get("dataset") in (f.get("datasets") or [])]
        out[c["key"]] = cols
    return out


def filterbar(cfg, data):
    filters = cfg.get("filters", [])
    if not filters:
        return ""
    parts = []
    for f in filters:
        col = f["column"]
        vals = set()
        for c in cfg.get("charts", []):
            if c.get("dataset") in (f.get("datasets") or []):
                for r in (data.get("rows") or {}).get(c["key"], []):
                    if col in r:
                        vals.add(str(r[col]))
        defaults = f.get("default") or []
        vals.update(str(v) for v in defaults)
        opts = "".join('<option value="%s"%s>%s</option>' % (
            esc(v), ' selected' if str(v) in {str(x) for x in defaults} else '',
            esc(v)) for v in sorted(vals))
        parts.append('<label class="flt">%s '
                     '<select data-col="%s"><option value="">все</option>%s'
                     '</select></label>' % (esc(f["name"]), esc(col), opts))
    return '<div class="filters">%s</div>' % "".join(parts)


def render(cfg, data):
    tabs = cfg.get("tabs", [])
    charts = {c["key"]: c for c in cfg.get("charts", [])}
    fmap = fcol_map(cfg)
    nav = "".join('<button type="button" role="tab" aria-selected="%s" aria-controls="panel-%d" tabindex="%d" class="tab%s">%s</button>'
                  % ("true" if i == 0 else "false", i, 0 if i == 0 else -1,
                     " on" if i == 0 else "", esc(t["name"]))
                  for i, t in enumerate(tabs))
    fbar = filterbar(cfg, data)
    secs = []
    for i, t in enumerate(tabs):
        rows_html = ""
        if t.get("markdown"):
            rows_html += md(t["markdown"])
        for row in t.get("rows", []):
            row_html = ""
            for it in row:
                ch = charts.get(it["chart"])
                if ch is None:
                    raise SystemExit("tabs: ссылка на несуществующий чарт '%s'"
                                     % it.get("chart"))
                row_html += '<div style="flex:%d">%s</div>' % (
                    it.get("w", 6), widget(ch, data, fmap.get(ch["key"], ())))
            rows_html += '<div class="row">%s</div>' % row_html
        secs.append('<section id="panel-%d" role="tabpanel" class="tabsec" style="display:%s">%s</section>'
                    % (i, "block" if i == 0 else "none", rows_html))
    return """<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>%s</title><style>
:root{%s}*{box-sizing:border-box}
body{margin:0;background:var(--canvas);color:var(--text);font-family:system-ui,Segoe UI,sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:20px}
h1{font-size:20px;margin:0 0 12px}
.tab{background:var(--soft);color:var(--accent);border:0;padding:8px 16px;border-radius:10px;font-weight:600;cursor:pointer;margin-right:6px}
.tab.on{background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.08)}
.row{display:flex;gap:10px;margin-bottom:10px}
@media(max-width:720px){.wrap{padding:12px}.row{display:block}.row>div{margin-bottom:10px}.row .card{height:auto}}
.card{background:#fff;border:1px solid var(--border);border-radius:var(--radius);padding:12px;height:100%%}
.ct{font-size:13px;font-weight:600;color:var(--accent);margin-bottom:8px}
.big{font-size:28px;font-weight:700}
.md h3{color:var(--accent);margin:8px 0}
.md p{margin:4px 0;color:var(--muted)}
.ph{color:var(--muted);font-size:12px;border:1px dashed var(--border);border-radius:10px;padding:10px}
.bars{display:flex;flex-direction:column;gap:6px}
.bar{display:flex;align-items:center;gap:8px;font-size:12px}
.bar .lbl{width:38%%;color:var(--muted);text-align:right}
.bar .track{flex:1;background:var(--soft);border-radius:6px;height:14px}
.bar .track i{display:block;height:14px;background:var(--series-color,var(--accent));border-radius:6px}
.series-legend{display:flex;gap:10px;flex-wrap:wrap;margin-top:8px;font-size:12px;color:var(--muted)}
.series-legend span{display:flex;align-items:center;gap:4px}.series-legend i{width:10px;height:10px;border-radius:50%%;display:inline-block}
.bar .val{width:14%%}
.line-chart,.bubble-chart{display:block;width:100%%;height:auto;max-height:300px}
.line-legend{display:flex;gap:12px;flex-wrap:wrap;font-size:12px;color:var(--muted)}
table{width:100%%;border-collapse:collapse;font-size:12px}
th{background:var(--soft);color:var(--accent);padding:8px;text-align:left}
td{border-bottom:1px solid var(--border);padding:6px 8px}
.filters{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 12px}
.flt{font-size:12px;color:var(--muted);display:flex;flex-direction:column;gap:4px}
.flt select{border:1px solid var(--border);border-radius:8px;padding:5px 8px;font:inherit;color:var(--text);background:#fff}
</style></head><body><div class="wrap">
<h1>%s <span style="color:var(--muted);font-weight:400;font-size:12px">(HTML-адаптер · BI)</span></h1>
%s<div>%s</div>%s
</div><script>
var tabs=document.querySelectorAll('.tab'),secs=document.querySelectorAll('.tabsec');
function showTab(i){tabs.forEach(function(x,j){var on=i===j;x.classList.toggle('on',on);x.setAttribute('aria-selected',on?'true':'false');x.tabIndex=on?0:-1;secs[j].style.display=on?'block':'none';});tabs[i].focus();}
tabs.forEach(function(b,i){b.onclick=function(){showTab(i);};b.onkeydown=function(e){if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();showTab((i+(e.key==='ArrowRight'?1:tabs.length-1))%%tabs.length);}};});
function applyFlt(){
  var act={};
  document.querySelectorAll('.filters select').forEach(function(s){
    if(s.value){(act[s.dataset.col]=act[s.dataset.col]||[]).push(s.value);}});
   document.querySelectorAll('[data-f]').forEach(function(el){
    var o=JSON.parse(el.getAttribute('data-f')||'{}'),ok=true;
    for(var col in act){if(col in o&&act[col].indexOf(String(o[col]))<0){ok=false;break;}}
     el.style.display=ok?'':'none';});
   document.querySelectorAll('polyline[data-line-series]').forEach(function(line){
     var key=line.dataset.lineSeries,pts=Array.from(document.querySelectorAll('circle[data-line-series]'))
       .filter(function(c){return c.dataset.lineSeries===key&&c.style.display!=='none';})
       .map(function(c){return c.getAttribute('cx')+','+c.getAttribute('cy');});
     line.setAttribute('points',pts.join(' '));
   });
   document.querySelectorAll('.big[data-rows]').forEach(function(el){
     var rows=JSON.parse(el.getAttribute('data-rows')||'[]'),cols=JSON.parse(el.getAttribute('data-fcols')||'[]');
     rows=rows.filter(function(r){return cols.every(function(c){return !act[c]||!act[c].length||act[c].indexOf(String(r[c]))>=0;});});
     var col=el.dataset.col,agg=el.dataset.agg||'SUM',vals=rows.map(function(r){return r[col];}).filter(function(v){return v!==null&&v!==undefined&&v!=='';});
     var n=vals.map(Number).filter(Number.isFinite),out='—';
     if(agg==='COUNT')out=String(vals.length);
     else if(agg==='COUNT_DISTINCT')out=String(new Set(vals.map(String)).size);
     else if(n.length){if(agg==='AVG')out=(n.reduce(function(a,b){return a+b;},0)/n.length).toLocaleString('ru-RU');
       else if(agg==='MIN')out=Math.min.apply(null,n).toLocaleString('ru-RU');
       else if(agg==='MAX')out=Math.max.apply(null,n).toLocaleString('ru-RU');
       else out=n.reduce(function(a,b){return a+b;},0).toLocaleString('ru-RU');}
     el.textContent=out;
   });
}
document.querySelectorAll('.filters select').forEach(function(s){s.onchange=applyFlt;});
applyFlt();
</script></body></html>""" % (esc(cfg["dashboard"]["title"]), DIT,
                              esc(cfg["dashboard"]["title"]), fbar, nav,
                              "".join(secs))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--data", help="JSON с values/rows (опционально)")
    ap.add_argument("--out")
    a = ap.parse_args()

    def _load(path, what):
        try:
            return json.load(open(path, encoding="utf-8-sig"))
        except FileNotFoundError:
            raise SystemExit("%s: файл не найден: %s" % (what, path))
        except json.JSONDecodeError as e:
            raise SystemExit("%s: невалидный JSON (%s, строка %d, столбец %d)"
                             % (what, e.msg, e.lineno, e.colno))

    cfg = _load(a.config, "config")
    data = _load(a.data, "data") if a.data else {}
    if cfg.get("filters") and not a.data:
        print("HTML-адаптер: фильтры есть, но без --data нет значений — "
              "выпадающие списки будут пустыми")
    slug = re.sub(r"[^0-9a-zA-Zа-яА-Я]+", "_", cfg["dashboard"]["title"]).strip("_")
    out = a.out or os.path.join("out", slug + ".html")
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    open(out, "w", encoding="utf-8").write(render(cfg, data))
    print("HTML-дашборд: %s" % out)


if __name__ == "__main__":
    main()
