#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Единый стандарт стиля ДИТ.Стат для дашбордов Superset.

Применяет базовый шаблон CSS (dit_stat_base.css: Часть A + общие FIX-правки)
к указанным дашбордам и добавляет правило для их markdown-виджетов.

Использование:
  python apply_dit_css.py <dashboard_id>                 # применить к дашборду <dashboard_id>
  python apply_dit_css.py <dashboard_id>         # к нескольким
  python apply_dit_css.py --list              # показать дашборды и статус
  python apply_dit_css.py --all               # ко всем БЕЗ стандарта (безопасно)
  python apply_dit_css.py --all --force       # ко всем, даже уже со стандартом

Стандарт: акцент #0062E1, шрифт Golos, фон #EEEFF3, радиус 16px.
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BASE_CSS = os.path.join(HERE, "dit_stat_base.css")
MARK = "ДИТ.Стат — единый шаблон CSS"
ACCENT = "#0062E1"

PROXY_DIR = os.environ.get("SUPERSET_PROXY_DIR")
if not PROXY_DIR:
    raise SystemExit(
        "SUPERSET_PROXY_DIR не задан. Укажите путь к SSO-прокси явно "
        "(для тестов — pipeline/tests). Отказ, чтобы случайно не записать "
        "в реальный инстанс Superset.")
if PROXY_DIR not in sys.path:
    sys.path.insert(0, PROXY_DIR)
import superset_session_proxy as sp  # noqa: E402


def api():
    s = sp.SupersetSession()
    s.login()
    csrf = json.loads(s.redirect("GET", "/api/v1/security/csrf_token/",
                                 {"Accept": "application/json"}, None)[1]
                      )["result"]
    ref = (os.environ.get("SUPERSET_URL") or
           "https://ditstat.idit.mos.ru").rstrip("/") + "/"

    def req(method, path, body=None):
        h = {"Accept": "application/json", "Content-Type": "application/json",
             "X-CSRFToken": csrf, "Referer": ref}
        data = json.dumps(body).encode() if body is not None else None
        st, b, _ = s.redirect(method, path, h, data)
        try:
            return st, json.loads(b)
        except Exception:
            return st, b[:300]
    return req


def build_css(req, did):
    st, r = req("GET", "/api/v1/dashboard/%d" % did)
    if st != 200:
        return None, None, None
    res = r["result"]
    pos = json.loads(res["position_json"] or "{}")
    md = [k for k, v in pos.items()
          if isinstance(v, dict) and v.get("type") == "MARKDOWN"]
    css = open(BASE_CSS, encoding="utf-8").read()
    if md:
        sel = ":is(" + ", ".join("#" + m for m in md) + ")"
        css += ("\n\n/* --- markdown-плашки этого дашборда --- */\n"
                "%s,\n%s .resizable-container,\n"
                "%s .dashboard-component-chart-holder {\n"
                "  background-color: var(--accent-soft) !important;\n"
                "  border-radius: var(--radius) !important;\n}\n"
                % (sel, sel, sel))
    return res, pos, css


def apply(req, did, force=False):
    res, pos, css = build_css(req, did)
    if res is None:
        print("  дашборд %s: не найден" % did)
        return False
    cur = res.get("css") or ""
    if not force and (MARK in cur or ACCENT in cur):
        print("  дашборд %s «%s»: уже по стандарту — пропуск" % (
            did, res["dashboard_title"][:40]))
        return False
    st, r = req("PUT", "/api/v1/dashboard/%d" % did, {
        "position_json": res["position_json"],
        "json_metadata": res["json_metadata"],
        "dashboard_title": res["dashboard_title"], "published": res["published"],
        "css": css})
    print("  дашборд %s «%s»: применён стандарт (%d симв.) -> %s" % (
        did, res["dashboard_title"][:40], len(css), st))
    return st == 200


def main():
    ap = argparse.ArgumentParser(description="Единый CSS-стандарт ДИТ.Стат")
    ap.add_argument("ids", nargs="*", type=int, help="id дашбордов")
    ap.add_argument("--all", action="store_true", help="все дашборды")
    ap.add_argument("--force", action="store_true",
                    help="перезаписать даже те, что уже со стандартом")
    ap.add_argument("--list", action="store_true", help="показать статус")
    args = ap.parse_args()

    req = api()
    if args.list:
        st, d = req("GET", "/api/v1/dashboard/?q=(page_size:300)")
        print("дашбордов: %s" % d.get("count"))
        for r in d.get("result", []):
            st2, rr = req("GET", "/api/v1/dashboard/%d" % r["id"])
            css = (rr["result"].get("css") or "") if st2 == 200 else ""
            mark = "СТАНДАРТ" if (MARK in css or ACCENT in css) else "нет"
            print("  %-5s %-55s %s" % (r["id"], r["dashboard_title"][:55], mark))
        return

    ids = args.ids
    if args.all:
        st, d = req("GET", "/api/v1/dashboard/?q=(page_size:300)")
        ids = [r["id"] for r in d.get("result", [])]
    if not ids:
        ap.error("укажите id дашборда(ов) или --all")

    ok = 0
    for did in ids:
        if apply(req, did, force=args.force):
            ok += 1
    print("готово: обновлено %d из %d" % (ok, len(ids)))


if __name__ == "__main__":
    main()
