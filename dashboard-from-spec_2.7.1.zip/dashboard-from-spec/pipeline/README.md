# Универсальный пайплайн дашбордов (source-agnostic, config-driven)

Набор переиспользуемых скриптов и соглашений для сборки дашбордов по единому стандарту:
**источник → данные → модель/витрина → БД → оркестрация → BI → ПМИ**.

> **Универсальность: пайплайн не привязан к домену.** Источник, сущности, метрики,
> методологии расчёта, дополнительный источник, платформа BI — **всё задаётся под задачу**
> (config + справочники). Примеры ниже (GitLab / Postgres / Superset / Airflow) —
> конкретная реализация ДИТ.Стат, но пайплайн переносим на другие источники/СУБД/BI/оркестраторы.

---

## 1. Этапы (доменно-агностичные)

```
01 Источник → факты        (API / БД / файлы / шина — любой)
02 Маппинг сущностей       (справочник + override-правила, любая иерархия)
03 Модель                  (dim_*/fact_*, метрики и формулы — из конфига, не в коде)
04 Материализация в БД      (схема <project>_metrics, витрины, DQ-гейты)
05 Оркестрация             (скрипт+DAG; метод загрузки — по задаче)
06 Сборка BI               (декларативно из config.json; для Superset — build_superset.py)
07 ПМИ / QA
```

Ни один этап не «зашит» под конкретную систему: меняется **источник**, **набор сущностей**,
**метрики/формулы**, **гранулярность** — код и процесс остаются.

---

## 2. Требования

- Python 3.11+, `psycopg2-binary`, `openpyxl` (+`jsonschema` для валидации конфига).
- Креды источников/БД/BI — **только через env/секрет-файл** (не в коде/гите).
- Для записи в БД — доступ и **схема** приёмника; для BI — подключение к целевой БД.

## 3. Запуск

```powershell
# 01 источник (скрипт под конкретный источник):               → data/, out/
# 02 маппинг (справочник + override):                          → таблица маппинга
# 03 модель (dim/fact, метрики из конфига):                    → out/*.csv
# 04 материализация: DDL + views + DQ (шаблон loader.py/dq_checks.py) → схема
# 05 оркестрация: скрипт → DAG (шаблон dag.py) + Git (git_ops.py)
# 06 BI: декларативно — выберите адаптер (Superset ИЛИ HTML)
# BI = Superset:
python pipeline/build_superset.py --config config.json --dry-run   # проверка
python pipeline/build_superset.py --config config.json             # сборка
python pipeline/apply_dit_css.py <dashboard_id>                    # единый стиль
# BI = HTML (самодостаточная витрина, без BI-платформы):
python pipeline/render_html.py --config config.json [--data data.json]
```

## 4. Конфигурация (декларативная)

Дашборд описывается **данными** (`config.json`), а не кодом. Ключевое (любые имена/метрики):

```jsonc
{
  "database_id": 14, "schema": "<project>_metrics",
  "dashboard": { "title": "<название>", "published": true },
  "datasets": [ { "table": "<витрина>",
                  "ru": { "<колонка>": "<Русская подпись>" } } ],
  "charts": [ { "key":"k1","name":"<заголовок>","dataset":"<витрина>",
                "viz":"echarts_timeseries_bar","x_axis":"<колонка>",
                "metrics":[ { "col":"<колонка>","agg":"SUM","label":"<метрика>" } ],
                "description":"<формула/источник>" } ],
  "tabs":   [ { "name":"Обзор","markdown":"…","rows":[[{"chart":"k1","w":6}]] } ],
  "filters":[ { "name":"<Фильтр>","column":"<колонка>","datasets":["<витрина>"] } ]
}
```

- `ru` — русские подписи колонок (`verbose_name`).
- Идентификатор чарта хранится в Superset с namespace дашборда; одинаковые chart keys разных проектов не переиспользуются.
- **метрики/формулы** задаются в `metrics`/`metric` (SIMPLE или SQL-выражение) — **под задачу**.
- `viz` — тип визуализации (для Superset: `echarts_timeseries_bar/line`, `table`,
  `big_number_total`, `bubble_v2`).
- валидация — `--dry-run` (JSON-схема + проверки).

HTML-адаптер поддерживает KPI из `data.values` и пересчитывает их при фильтрах,
если для KPI также переданы исходные строки в `data.rows[chart_key]`. Для корректного
пересчёта и фильтрации в `rows` нужны исходные колонки метрик и применимых фильтров.
Графики и таблицы ожидают уже агрегированные строки. Нет данных метрики — ошибка,
а не молчаливый ноль. Дашборд остаётся статическим HTML без запросов к БД.

## ETL: обязательная адаптация шаблона

`skill/templates/loader.py` намеренно не имитирует пустой успешный extract: до
внедрения конкретного источника реализуйте `extract(cursor) -> (rows, new_cursor)`.
Настройте `DDL_ENV` для схемы таблицы, отличной от примера. `PARTREPL` требует
`partition_key` в `COLUMNS` и одинакового значения ключа у всех загружаемых строк.
Исторический `SNAPSHOT` требует `snapshot_date` в `COLUMNS` и `KEY_COLS`, а также
DDL с составным primary/unique key (обычно `(id, snapshot_date)`). По умолчанию
SNAPSHOT — текущее состояние, а не история. `DELTA` не удаляет строки (UPSERT).

Загрузка через `main()` сохраняет строки и watermark в одной транзакции.
`load()`/`save_cursor()` при прямом вызове по умолчанию коммитят отдельно; для
составного шага используйте `commit=False` и один внешний `commit()`.

### Offline-регрессии

```powershell
python -m pip install -r pipeline/tests/requirements-test.txt
python -m pytest pipeline/tests/qa/test_contracts.py pipeline/tests/qa/test_loader.py -q
python pipeline/tests/smoke_test.py
```

SQL-тесты в `pipeline/tests/qa/test_postgres.py` запускаются только с явно заданным
`QA_POSTGRES_DSN` на изолированной тестовой БД. Их не запускайте на production.

Пример: `config.example.generic.json` (нейтральный — продажи/регионы, чтобы показать
доменную-агностичность).

## 5. Известные ограничения целевой платформы (Superset — пример)

| # | Проблема | Решение |
|---|---|---|
| 1 | viz `bar`/`line`/`bubble` не зарегистрированы | `echarts_timeseries_bar`/`_line`, `bubble_v2`, `table`, `big_number_total` |
| 2 | «не связана ни одна диаграмма» | `PUT /chart/{id} {"dashboards":[id]}` |
| 3 | native-фильтр с `defaultDataMask` роняет фронт | корректный `defaultDataMask` формируется при заданном default; проверьте на целевой версии Superset |
| 4 | `GET /chart/{id}/data/` → 400 | проверять `POST /chart/data` |
| 5 | кэш отдаёт старое | `cache_timeout=0` |
| 6 | view изменили — датасет не видит колонки | `PUT /dataset/{id}/refresh` |
| 7 | английские подписи | `verbose_name` (`ru`) |
| 8 | гистограммы в ячейках | `show_cell_bars=false` |

## 6. Чеклист нового дашборда

1. Источник и гранулярность → этап 01.
2. Справочник сущностей + правила → 02.
3. Модель dim/fact, метрики из конфига → 03.
4. Материализация в схему + DQ → 04.
5. Описать дашборд в `config.json` → 06.
6. Стиль (единый) → `apply_dit_css.py`.
7. ПМИ: рендер, сверка, латентность, визуальная проверка.
8. Доступы ролям (RLS — вручную у админа сервиса).

## 7. Состав пайплайна

`superset_client.py` (клиент BI-платформы Superset) · `build_superset.py` (сборка дашборда
в Superset) · `render_html.py` (**альтернативный BI-адаптер**: `config.json` → статический HTML) ·
`apply_dit_css.py` + `dit_stat_base.css` (единый стиль) · `config.schema.json` (схема конфига) ·
`config.example.generic.json` (пример) · `data.example.json` (данные для HTML).
Шаблоны данных/DAG — в скилле `../skill/templates/` (loader, dag, git_ops, dq_checks,
promote, db_backup, freshness_check, estimate, RUNBOOK, постановка, реестр).

## 8. Расширяемость: ядро + адаптеры

Универсальность = **стабильное ядро (контракты) + сменные адаптеры под платформу**.

**Ядро (не меняется по домену):** конфиг-спецификация (`config.json`), схема витрины,
mapping/метрики, DQ-контракты.

**Адаптеры (сменные, по платформе):**

| Адаптер | Контракт | Реализация (пример) |
|---|---|---|
| Source | `extract(cursor) → (rows, new_cursor)` | API / БД / файлы (скрипт под источник) |
| Sink | `load(rows, method, key)` | `loader.py` (Postgres; для др. СУБД — свой) |
| BI | `deploy(spec)` | `build_superset.py` (Superset; для др. BI — свой) |
| Orchestrator | «шедулер → `loader.py` с env» | `dag.py` (Airflow; cron/K8s/Dagster — свои) |
| SCM | ветка/коммит/MR | `git_ops.py` (GitLab; GitHub/Bitbucket — свои) |

Переносится: **процесс + конфиг + метрики**. Меняется при смене платформы — только адаптер.

Опциональный блок `connectors` в конфиге фиксирует выбор реализации
(`{"source":"gitlab","sink":"postgres","bi":"superset","orchestrator":"airflow"}`).

## 9. Граница доверия (trust boundary)

`config.json` считается **доверенным артефактом внутреннего контура**:

- **SQL-метрики** (`metrics[].sql`) и `adhoc_filters` уходят в Superset как есть
  (`sqlExpression`) и выполняются **от имени сервисной учётной записи** датасета.
  Кто правит конфиг — тот выполняет SQL с правами этой учётки.
- Идентификаторы (schema/table/columns) в `loader`/`dq_checks`/`freshness` проходят
  `_ident` (regex) — защита от инъекции через имена.
- `promote.py`: шаги ограничены `PROMOTE_ALLOW`; `python -c` запрещён по умолчанию
  (нужен `PROMOTE_ALLOW_RCE=1`).
- Секреты — **не в конфиге**: через `env_file`, Connections/Secret Backend, переменные окружения.

Внешним/недоверенным конфиг делать нельзя без ревью SQL-метрик.
