#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_superset.py — декларативная сборка дашборда Superset из config.json.

    python build_superset.py --config config.json

Идемпотентно: датасеты/чарты ищутся по имени (чарты — по стабильному ключу
`[dash-key:…]` в description, чтобы переименование не порождало сирот); дашборд обновляется.
См. pipeline/README.md и config.example.generic.json.
"""
import argparse
import json
import os
import re
import sys
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# ВАЖНО: Superset импортируется ЛЕНИВО (внутри main) — чтобы --dry-run и валидация
# работали офлайн, без SSO-прокси и клиента платформы.


def load_env_file(path):
    if path and os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(),
                                          v.strip().strip('"').strip("'"))


REQUIRED = ["database_id", "schema", "dashboard", "datasets", "charts", "tabs"]
VIZ_ENUM = {"echarts_timeseries_bar", "echarts_timeseries_line", "table",
            "big_number_total", "big_number", "bubble_v2"}
VIZ_REQUIRED = {
    "big_number_total": ("metric",), "big_number": ("metric",),
    "bubble_v2": ("x", "y", "size"),
    "table": ("groupby", "metrics"),
    "echarts_timeseries_bar": ("x_axis", "metrics"),
    "echarts_timeseries_line": ("x_axis", "metrics"),
}
AGG_ENUM = {"SUM", "AVG", "COUNT", "MIN", "MAX", "COUNT_DISTINCT"}


def validate_schema(cfg, schema_path):
    """Валидация по JSON-схеме (если установлен jsonschema)."""
    if not os.path.exists(schema_path):
        return
    try:
        import jsonschema
    except ImportError:
        print("jsonschema не установлен — пропускаю проверку по схеме")
        return
    schema = json.load(open(schema_path, encoding="utf-8"))
    try:
        jsonschema.validate(cfg, schema)
        print("config соответствует JSON-схеме")
    except jsonschema.ValidationError as e:
        raise SystemExit("config не соответствует схеме: %s (путь: %s)"
                         % (e.message, list(e.path)))


def validate_config(cfg):
    if not isinstance(cfg, dict):
        raise SystemExit("config: корнем JSON должен быть объект")
    miss = [k for k in REQUIRED if k not in cfg]
    if miss:
        raise SystemExit("config: нет обязательных ключей: %s" % miss)
    for key in ("datasets", "charts", "tabs"):
        if not isinstance(cfg.get(key), list) or not cfg[key]:
            raise SystemExit("config.%s: нужен непустой список" % key)
    if "filters" in cfg and not isinstance(cfg["filters"], list):
        raise SystemExit("config.filters: ожидается список")
    if "dashboard_id" in cfg and (type(cfg["dashboard_id"]) is not int or
                                    cfg["dashboard_id"] < 1):
        raise SystemExit("config.dashboard_id: должен быть числом")
    env = cfg.get("env")
    if env:
        envs = cfg.get("environments")
        if not envs:
            raise SystemExit("config.env='%s', но блок 'environments' отсутствует "
                             "(среда не переключится)" % env)
        if env not in envs:
            raise SystemExit("config.env='%s' нет в 'environments'" % env)

    def check_metric(m, where):
        if not isinstance(m, dict):
            raise SystemExit("%s: метрика должна быть объектом" % where)
        if m.get("sql") and m.get("col"):
            raise SystemExit("%s: укажите 'col' ИЛИ 'sql', не оба" % where)
        if not (m.get("sql") or m.get("col")):
            raise SystemExit("%s: метрика без 'col' или 'sql'" % where)
        if m.get("sql") is not None and not isinstance(m["sql"], str):
            raise SystemExit("%s: 'sql' метрики должен быть строкой" % where)
        if m.get("col") and m.get("agg", "SUM") not in AGG_ENUM:
            raise SystemExit("%s: agg='%s' не поддержан ({%s})"
                             % (where, m.get("agg"), ", ".join(sorted(AGG_ENUM))))

    if not isinstance(cfg.get("dashboard"), dict) or "title" not in cfg["dashboard"]:
        raise SystemExit("config.dashboard: нужен объект с 'title'")
    for i, d in enumerate(cfg.get("datasets", [])):
        if not isinstance(d, dict):
            raise SystemExit("config.datasets[%d]: должен быть объект" % i)
        if "table" not in d:
            raise SystemExit("config.datasets[%d]: нет 'table'" % i)
    dtables = [d["table"] for d in cfg.get("datasets", [])]
    if len(dtables) != len(set(dtables)):
        raise SystemExit("config.datasets: дубли таблиц: %s"
                         % sorted({t for t in dtables if dtables.count(t) > 1}))
    keys, names = [], []
    for i, ch in enumerate(cfg.get("charts", [])):
        if not isinstance(ch, dict):
            raise SystemExit("config.charts[%d]: должен быть объектом" % i)
        for k in ("key", "name", "dataset", "viz"):
            if k not in ch:
                raise SystemExit("config.charts[%d]: нет '%s'" % (i, k))
        if ch["viz"] not in VIZ_ENUM:
            raise SystemExit("config.charts[%s]: viz '%s' не поддержан ({%s})"
                             % (ch["key"], ch["viz"], ", ".join(sorted(VIZ_ENUM))))
        for f in VIZ_REQUIRED.get(ch["viz"], ()):
            if f not in ch:
                raise SystemExit("config.charts[%s]: для viz '%s' нужен '%s'"
                                 % (ch["key"], ch["viz"], f))
        for m in (ch.get("metrics") or []):
            check_metric(m, "charts[%s].metrics" % ch["key"])
        if isinstance(ch.get("metric"), dict):
            check_metric(ch["metric"], "charts[%s].metric" % ch["key"])
        for f in ("x", "y", "size"):
            if isinstance(ch.get(f), dict):
                check_metric(ch[f], "charts[%s].%s" % (ch["key"], f))
        keys.append(ch["key"])
        names.append(ch["name"])
    if len(keys) != len(set(keys)):
        raise SystemExit("config.charts: дубли ключей: %s"
                         % sorted({k for k in keys if keys.count(k) > 1}))
    if len(names) != len(set(names)):
        raise SystemExit("config.charts: дубли имён (перехват объектов): %s"
                         % sorted({n for n in names if names.count(n) > 1}))
    tables = [d["table"] for d in cfg.get("datasets", [])]
    for ch in cfg["charts"]:
        if ch["dataset"] not in tables:
            raise SystemExit("config.charts[%s]: датасет '%s' не объявлен"
                             % (ch["key"], ch["dataset"]))
    placed = set()
    for t in cfg.get("tabs", []):
        if not isinstance(t, dict):
            raise SystemExit("config.tabs: каждый элемент должен быть объектом")
        if not t.get("rows"):
            raise SystemExit("config.tabs: вкладка '%s' без строк" % t.get("name"))
        for row in t.get("rows", []):
            if not isinstance(row, list):
                raise SystemExit("config.tabs[%s]: строка должна быть списком" % t.get("name"))
            width = 0
            for it in row:
                if not isinstance(it, dict):
                    raise SystemExit("config.tabs[%s]: элемент строки должен быть объектом" % t.get("name"))
                key = it.get("chart")
                if key not in keys:
                    raise SystemExit("config.tabs: ссылка на несуществующий "
                                     "чарт '%s'" % key)
                if key in placed:
                    raise SystemExit("config.tabs: чарт '%s' размещён более "
                                     "одного раза" % key)
                placed.add(key)
                w = it.get("w", 0)
                if w <= 0:
                    raise SystemExit("config.tabs: недопустимая ширина w=%s у '%s'"
                                     % (w, key))
                width += w
            if width > 12:
                raise SystemExit("config.tabs: строка вкладки '%s' шире 12 (w=%s)"
                                 % (t.get("name"), width))
    orphan = [k for k in keys if k not in placed]
    if orphan:
        raise SystemExit("config.charts: не размещены ни в одной вкладке: %s"
                         % orphan)
    for f in cfg.get("filters", []):
        if not isinstance(f, dict):
            raise SystemExit("config.filters: каждый элемент должен быть объектом")
    fnames = [f.get("name") for f in cfg.get("filters", [])]
    if len(fnames) != len(set(fnames)):
        raise SystemExit("config.filters: дубли имён: %s"
                         % sorted({n for n in fnames if fnames.count(n) > 1}))
    for f in cfg.get("filters", []):
        if not f.get("name"):
            raise SystemExit("config.filters: у фильтра нет 'name'")
        if not f.get("column"):
            raise SystemExit("config.filters[%s]: нет 'column'" % f.get("name"))
        if "default" in f and not isinstance(f["default"], list):
            raise SystemExit("config.filters[%s]: 'default' должен быть массивом"
                             % f.get("name"))
        if not f.get("datasets"):
            raise SystemExit("config.filters[%s]: пустой 'datasets'"
                             % f.get("name"))
        for t in f.get("datasets", []):
            if t not in tables:
                raise SystemExit("config.filters[%s]: датасет '%s' не объявлен"
                                 % (f.get("name"), t))
    print("config OK: датасетов %d, чартов %d, вкладок %d, фильтров %d" % (
        len(tables), len(keys), len(cfg["tabs"]), len(cfg.get("filters", []))))


def resolve_env(cfg):
    """Среды test/prod: cfg['env'] + cfg['environments'][env] перекрывают базу."""
    env = cfg.get("env")
    envs = cfg.get("environments")
    if env and envs and env in envs:
        ov = envs[env]
        for k in ("database_id", "schema"):
            if k in ov:
                cfg[k] = ov[k]
        if "env_file" in ov:
            cfg.setdefault("superset", {})["env_file"] = ov["env_file"]
        if "css_template" in ov:
            cfg["css_template"] = ov["css_template"]
        if "title" in ov:
            cfg["dashboard"]["title"] = ov["title"]
        print("среда: %s (database_id=%s, schema=%s)"
              % (env, cfg["database_id"], cfg["schema"]))
    return cfg


def metric(m):
    if "sql" in m:
        return {"expressionType": "SQL", "sqlExpression": m["sql"],
                "label": m.get("label", m["sql"])}
    return {"expressionType": "SIMPLE",
            "column": {"column_name": m["col"]},
            "aggregate": m.get("agg", "SUM"),
            "label": m.get("label", m["col"])}


def build_params(cfg, chart, ds_id):
    viz = chart["viz"]
    p = {"datasource": "%d__table" % ds_id, "viz_type": viz,
         "time_range": "No filter", "row_limit": chart.get("row_limit", 500)}
    if chart.get("adhoc_filters"):
        p["adhoc_filters"] = chart["adhoc_filters"]
    if viz in ("echarts_timeseries_bar", "echarts_timeseries_line"):
        p["x_axis"] = chart.get("x_axis")
        p["metrics"] = [metric(m) for m in chart.get("metrics", [])]
        if chart.get("groupby"):
            p["groupby"] = chart["groupby"]
        if chart.get("orientation"):
            p["orientation"] = chart["orientation"]
    elif viz == "table":
        p["groupby"] = chart.get("groupby", [])
        p["metrics"] = [metric(m) for m in chart.get("metrics", [])]
        p["show_cell_bars"] = False
    elif viz in ("big_number", "big_number_total"):
        p["metric"] = metric(chart["metric"])
    elif viz == "bubble_v2":
        p["series"] = chart.get("series")
        p["entity"] = chart.get("entity")
        for k in ("x", "y", "size"):
            p[k] = metric(chart[k])
    return p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--dry-run", action="store_true",
                    help="только проверить конфиг, ничего не записывать")
    args = ap.parse_args()
    try:
        cfg = json.load(open(args.config, encoding="utf-8-sig"))
    except FileNotFoundError:
        raise SystemExit("config: файл не найден: %s" % args.config)
    except json.JSONDecodeError as e:
        raise SystemExit("config: невалидный JSON (%s, строка %d, столбец %d)"
                         % (e.msg, e.lineno, e.colno))
    cfg = resolve_env(cfg)
    load_env_file((cfg.get("superset") or {}).get("env_file"))
    schema_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "config.schema.json")
    validate_schema(cfg, schema_path)
    validate_config(cfg)
    if args.dry_run:
        print("--dry-run: конфиг валиден, запись в Superset не выполняется")
        return

    from superset_client import Superset
    ss = Superset()
    schema, dbid = cfg["schema"], cfg["database_id"]

    # 1) датасеты
    ds_ids = {}
    for d in cfg["datasets"]:
        did = ss.ensure_dataset(dbid, schema, d["table"])
        if did is None:
            raise SystemExit("не удалось создать/найти датасет '%s'" % d["table"])
        ds_ids[d["table"]] = did
        if d.get("ru"):
            ss.set_dataset_ru(did, d["ru"])
        print("dataset %-18s id=%s" % (d["table"], did))

    # 2) дашборд (создаём/находим)
    dash_id = cfg.get("dashboard_id")
    if dash_id:
        st, _ = ss.req("GET", "/api/v1/dashboard/%s" % dash_id)
        if st != 200:
            raise SystemExit("dashboard_id=%s не найден (HTTP %s)"
                             % (dash_id, st))
    if not dash_id:
        dash_id = ss.find_dashboard(cfg["dashboard"]["title"])
        if dash_id:
            print("  (дашборд найден по title; для защиты от коллизии "
                  "задайте dashboard_id)")
        if not dash_id:
            dash_id = ss.create_dashboard(cfg["dashboard"]["title"],
                                          cfg["dashboard"].get("published", True))
        if not dash_id:
            raise SystemExit("не удалось создать/найти дашборд")
    print("dashboard id=%s" % dash_id)

    # 3) чарты (idempotent по стабильному ключу из description; фолбэк — по имени)
    by_name, by_key = {}, {}
    page = 0
    while True:
        st, existing = ss.req(
            "GET", "/api/v1/chart/?q=(page_size:100,page:%d)" % page)
        res = existing.get("result", [])
        for r in res:
            by_name[r["slice_name"]] = r["id"]
            m = re.search(r"\[dash-key:([^\]]+)\]", r.get("description") or "")
            if m:
                by_key[m.group(1)] = r["id"]
        if len(res) < 100:
            break
        page += 1
    chart_ids = {}
    for ch in cfg["charts"]:
        did = ds_ids[ch["dataset"]]
        params = build_params(cfg, ch, did)
        scoped_key = "%s:%s" % (dash_id, ch["key"])
        desc = "[dash-key:%s]%s" % (
            scoped_key, " " + ch["description"] if ch.get("description") else "")
        cid = by_key.get(scoped_key)
        # Migrate legacy global keys/names only when Superset confirms the chart
        # is already linked to this dashboard. Never mutate another dashboard's chart.
        legacy_id = by_key.get(ch["key"]) or by_name.get(ch["name"])
        if not cid and legacy_id:
            _, detail = ss.req("GET", "/api/v1/chart/%d" % legacy_id)
            linked = (detail.get("result") or {}).get("dashboards") or []
            linked_ids = {item.get("id") for item in linked if isinstance(item, dict)}
            if int(dash_id) in linked_ids:
                cid = legacy_id
        if cid:
            ss.set_chart(cid, slice_name=ch["name"], viz_type=ch["viz"],
                         datasource_id=did,
                         params=json.dumps(params, ensure_ascii=False),
                         description=desc)
        else:
            cid = ss.create_chart(ch["name"], ch["viz"], did, params, desc)
        if not cid:
            raise SystemExit("не удалось создать/найти чарт '%s'" % ch["name"])
        ss.link_chart(cid, dash_id)
        chart_ids[ch["key"]] = cid
        print("chart %-22s id=%s" % (ch["key"], cid))

    # 4) layout
    tabs = []
    for t in cfg["tabs"]:
        rows = [[{"chart": chart_ids[it["chart"]], "w": it.get("w", 6),
                  "name": _chart_name(cfg, it["chart"])} for it in row]
                for row in t.get("rows", [])]
        tabs.append({"name": t["name"], "markdown": t.get("markdown"),
                     "rows": rows})
    pos = ss.build_layout(cfg["dashboard"]["title"], tabs)

    # 5) фильтры
    filters = []
    for f in cfg.get("filters", []):
        filters.append(ss.make_filter(
            f["name"], f["column"],
            [ds_ids[t] for t in f["datasets"]],
            default=f.get("default")))

    # 6) CSS
    css = ""
    tpl = cfg.get("css_template")
    if tpl:
        p = tpl if os.path.isabs(tpl) else os.path.join(
            os.path.dirname(os.path.abspath(__file__)), tpl)
        if os.path.exists(p):
            css = open(p, encoding="utf-8").read()

    st, r = ss.save_dashboard(dash_id, cfg["dashboard"]["title"], pos, filters,
                              css, cfg["dashboard"].get("published", True))
    print("save dashboard ->", st)
    print("URL: %s/superset/dashboard/%s/" % (ss.base, dash_id))

    # last-known-good снапшот (для быстрого отката revert.py)
    try:
        import dashboard_state
        snap = dashboard_state.save(cfg, dash_id, ds_ids, chart_ids,
                                    os.path.dirname(os.path.abspath(__file__)))
        print("snapshot:", snap)
    except Exception as e:          # не блокируем сборку при сбое снапшота
        print("snapshot: не сохранился (%s)" % e)


def _chart_name(cfg, key):
    for ch in cfg["charts"]:
        if ch["key"] == key:
            return ch["name"]
    return ""


if __name__ == "__main__":
    main()
