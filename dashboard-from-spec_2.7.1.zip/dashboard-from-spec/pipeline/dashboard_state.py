#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""dashboard_state.py — last-known-good снапшоты конфигов дашбордов.

После успешной сборки build_superset сохраняет снапшот (разрешённого конфига +
id датасетов/чартов) в `state/` рядом с собой. Доступны перечисление и выбор
последнего перед указанным — для быстрого отката (revert.py).

  save(config, dash_id, ds_ids, chart_ids)      -> путь к снапшоту
  list_snapshots(dash_id)                       -> список снапшотов (старый→новый)
  latest_before(dash_id)                        -> самый свежий снапшот
  latest_before(dash_id, exclude_fn)            -> предыдущий к заданному

Хранит KEEP последних снапшотов на дашборд (обрезка). Пишет атомарно (.tmp → os.replace).
Чистый модуль без сети — тестируется офлайн.
"""
import glob
import json
import os
import time
import uuid

KEEP = 10


def state_dir(root):
    return os.path.join(root, "state")


def _snap(fn):
    with open(fn, encoding="utf-8-sig") as fh:
        payload = json.load(fh)
    return {"fn": fn,
            "ts": os.path.getmtime(fn),
            "config": payload["config"]}


def save(config, dash_id, ds_ids, chart_ids, root):
    """Сохранить снапшот dash_id. root — папка с build_superset.py (создаётся state/)."""
    d = state_dir(root)
    os.makedirs(d, exist_ok=True)
    # Include a monotonic-enough nanosecond component and random suffix: two
    # successful builds in one second must never overwrite last-known-good.
    fn = os.path.join(d, "d%s_%s_%020d_%s.json" % (
        dash_id, time.strftime("%Y%m%d_%H%M%S"), time.time_ns(),
        uuid.uuid4().hex[:8]))
    payload = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "dash_id": dash_id,
               "config": config, "ds_ids": ds_ids, "chart_ids": chart_ids}
    tmp = fn + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, fn)
    for old in sorted(glob.glob(os.path.join(d, "d%s_*.json" % dash_id)))[:-KEEP]:
        os.remove(old)
    return fn


def _for(dash_id, root):
    return sorted(glob.glob(os.path.join(state_dir(root), "d%s_*.json" % dash_id)),
                  key=lambda fn: (os.path.getmtime(fn), os.path.basename(fn)))


def list_snapshots(dash_id, root):
    return [_snap(f) for f in _for(dash_id, root)]


def latest_before(dash_id, root, exclude_fn=None):
    fns = [f for f in _for(dash_id, root) if f != exclude_fn]
    if not fns:
        return None
    return _snap(fns[-1])
