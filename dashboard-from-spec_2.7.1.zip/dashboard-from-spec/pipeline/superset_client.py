#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""superset_client.py — переиспользуемый клиент Superset ДИТ.Стат.

Сессию берёт из SSO-прокси-модуля (SupersetSession). Умеет GET/POST/PUT/DELETE,
работу с датасетами (создание, русские подписи, refresh), чартами (создание,
привязка к дашборду), дашбордами (layout из вкладок/строк/чартов, фильтры, CSS).

Зависимость: путь к `opencode-proxy` (где лежит superset_session_proxy.py).
"""
import copy
import json
import os
import sys
import uuid

PROXY_DIR = os.environ.get("SUPERSET_PROXY_DIR")
if not PROXY_DIR:
    raise SystemExit(
        "SUPERSET_PROXY_DIR не задан. Укажите путь к SSO-прокси явно "
        "(для тестов — pipeline/tests). Отказ, чтобы случайно не записать "
        "в реальный инстанс Superset.")
if PROXY_DIR not in sys.path:
    sys.path.insert(0, PROXY_DIR)

import superset_session_proxy as _proxy  # noqa: E402


class Superset:
    def __init__(self, base_url=None):
        self.s = _proxy.SupersetSession()
        self.s.login()
        self.base = (base_url or os.environ.get("SUPERSET_URL")
                     or "https://ditstat.idit.mos.ru").rstrip("/")
        self.csrf = json.loads(self.s.redirect(
            "GET", "/api/v1/security/csrf_token/",
            {"Accept": "application/json"}, None)[1])["result"]
        self._ds_cache = None

    def req(self, method, path, body=None, soft=False):
        h = {"Accept": "application/json", "Content-Type": "application/json",
             "X-CSRFToken": self.csrf, "Referer": self.base + "/"}
        data = json.dumps(body).encode() if body is not None else None
        st, b, _ = self.s.redirect(method, path, h, data)
        try:
            parsed = json.loads(b)
        except Exception:
            parsed = {"_raw": b[:300].decode("utf-8", "replace")}
        if not soft and st >= 400:
            raise RuntimeError("%s %s -> HTTP %s: %s"
                               % (method, path, st, str(parsed)[:250]))
        return st, parsed

    # ---------- датасеты ----------
    def _datasets(self, refresh=False):
        """Список всех датасетов (кэш на время жизни клиента — O(n) вместо O(n·m))."""
        if self._ds_cache is None or refresh:
            items, page = [], 0
            while True:
                st, d = self.req(
                    "GET", "/api/v1/dataset/?q=(page_size:100,page:%d)" % page)
                res = d.get("result", [])
                items.extend(res)
                if len(res) < 100:
                    break
                page += 1
            self._ds_cache = items
        return self._ds_cache

    def find_dataset(self, schema, table, database_id=None):
        for r in self._datasets():
            if (r.get("schema") or "") == schema \
                    and r.get("table_name") == table \
                    and (database_id is None
                         or (r.get("database") or {}).get("id") == database_id):
                return r["id"]
        return None

    def ensure_dataset(self, database_id, schema, table):
        did = self.find_dataset(schema, table, database_id)
        if did:
            return did
        st, r = self.req("POST", "/api/v1/dataset/",
                         {"database": database_id, "schema": schema,
                          "table_name": table})
        new = r.get("id") if isinstance(r, dict) else None
        if new is not None and self._ds_cache is not None:
            self._ds_cache.append({"id": new, "schema": schema,
                                   "table_name": table,
                                   "database": {"id": database_id}})
        return new

    def refresh_dataset(self, did):
        return self.req("PUT", "/api/v1/dataset/%d/refresh" % did)

    def set_dataset_ru(self, did, ru_map):
        """ru_map: {column_name: 'Русское имя'}."""
        st, r = self.req("GET", "/api/v1/dataset/%d" % did)
        cols = (r.get("result") or {}).get("columns") or []
        payload = [{"id": c["id"], "column_name": c["column_name"],
                    "verbose_name": ru_map.get(c["column_name"],
                                               c.get("verbose_name") or
                                               c["column_name"])}
                   for c in cols]
        return self.req("PUT", "/api/v1/dataset/%d" % did, {"columns": payload})

    # ---------- чарты ----------
    def create_chart(self, name, viz, ds_id, params, description=""):
        st, r = self.req("POST", "/api/v1/chart/", {
            "slice_name": name, "viz_type": viz, "datasource_id": ds_id,
            "datasource_type": "table",
            "params": json.dumps(params, ensure_ascii=False),
            "description": description})
        return r.get("id") if isinstance(r, dict) else None

    def link_chart(self, chart_id, dashboard_id):
        st, r = self.req("GET", "/api/v1/chart/%d" % chart_id)
        ids = [x["id"] for x in ((r.get("result") or {}).get("dashboards") or [])]
        if dashboard_id not in ids:
            ids.append(dashboard_id)
        return self.req("PUT", "/api/v1/chart/%d" % chart_id,
                        {"dashboards": ids})

    def set_chart(self, chart_id, **fields):
        return self.req("PUT", "/api/v1/chart/%d" % chart_id, fields)

    # ---------- дашборд ----------
    def find_dashboard(self, title):
        page = 0
        while True:
            st, d = self.req(
                "GET", "/api/v1/dashboard/?q=(page_size:100,page:%d)" % page)
            res = d.get("result", [])
            for r in res:
                if r.get("dashboard_title") == title:
                    return r["id"]
            if len(res) < 100:
                return None
            page += 1

    def create_dashboard(self, title, published=True):
        st, r = self.req("POST", "/api/v1/dashboard/",
                         {"dashboard_title": title, "published": published})
        return r.get("id")

    def build_layout(self, header, tabs):
        """tabs: [{'name':..,'markdown':..,'rows':[[{'chart':cid,'w':6,'name':..}]]}]"""
        pos = {"DASHBOARD_VERSION_KEY": "v2",
               "ROOT_ID": {"id": "ROOT_ID", "type": "ROOT",
                           "children": ["TABS-main"]},
               "HEADER_ID": {"id": "HEADER_ID", "type": "HEADER",
                             "meta": {"text": header}},
               "TABS-main": {"id": "TABS-main", "type": "TABS",
                             "children": [], "parents": ["ROOT_ID"], "meta": {}}}
        for ti, t in enumerate(tabs):
            tab_id = "TAB-%d" % ti
            pos["TABS-main"]["children"].append(tab_id)
            pos[tab_id] = {"id": tab_id, "type": "TAB", "children": [],
                           "parents": ["ROOT_ID", "TABS-main"],
                           "meta": {"text": t["name"], "defaultText": t["name"],
                                    "placeholder": t["name"]}}
            if t.get("markdown"):
                mk = "MARKDOWN-%d" % ti
                pos[mk] = {"id": mk, "type": "MARKDOWN", "children": [],
                           "parents": ["ROOT_ID", "TABS-main", tab_id],
                           "meta": {"code": t["markdown"], "width": 12,
                                    "height": 20, "sliceName": "Пояснение"}}
                pos[tab_id]["children"].append(mk)
            for ri, row in enumerate(t.get("rows", [])):
                rid = "ROW-%d-%d" % (ti, ri)
                keys = []
                for it in row:
                    ck = "CHART-%s" % it["chart"]
                    pos[ck] = {"id": ck, "type": "CHART", "children": [],
                               "parents": ["ROOT_ID", "TABS-main", tab_id, rid],
                               "meta": {"chartId": it["chart"],
                                        "width": it.get("w", 6), "height": 50,
                                        "sliceName": it.get("name", "")}}
                    keys.append(ck)
                pos[rid] = {"id": rid, "type": "ROW", "children": keys,
                            "parents": ["ROOT_ID", "TABS-main", tab_id],
                            "meta": {"background": "BACKGROUND_TRANSPARENT"}}
                pos[tab_id]["children"].append(rid)
        return pos

    @staticmethod
    def make_filter(name, column, dataset_ids, default=None):
        import hashlib
        fid = "NATIVE_FILTER-" + hashlib.md5(
            name.encode("utf-8"), usedforsecurity=False).hexdigest()[:20]
        if default:
            dm = {"extraFormData": {"filters": [{"col": column, "op": "IN",
                                                 "val": list(default)}]},
                  "filterState": {"value": list(default), "label": default[0],
                                  "validateMessage": False,
                                  "validateStatus": False}}
        else:
            dm = {"filterState": {}, "ownState": {}, "extraFormData": {}}
        return {"id": fid, "name": name, "filterType": "filter_select",
                "targets": [{"datasetId": ds, "column": {"name": column}}
                            for ds in dataset_ids],
                "controlValues": {"multiSelect": True, "enableEmptyFilter": False,
                                  "defaultToFirstItem": False,
                                  "searchAllOptions": True,
                                  "inverseSelection": False},
                "defaultDataMask": dm,
                "cascadeParentIds": [],
                "scope": {"rootPath": ["ROOT_ID"], "excluded": []},
                "type": "NATIVE_FILTER"}

    def save_dashboard(self, did, title, position, filters, css="",
                       published=True):
        meta = {"chart_configuration": {}, "default_filters": "{}",
                "filter_scopes": {}, "expanded_slices": {},
                "refresh_frequency": 0, "timed_refresh_immune_slices": [],
                "color_scheme": "", "label_colors": {},
                "native_filter_configuration": filters}
        return self.req("PUT", "/api/v1/dashboard/%d" % did, {
            "position_json": json.dumps(position, ensure_ascii=False),
            "json_metadata": json.dumps(meta, ensure_ascii=False),
            "dashboard_title": title, "published": published, "css": css})
