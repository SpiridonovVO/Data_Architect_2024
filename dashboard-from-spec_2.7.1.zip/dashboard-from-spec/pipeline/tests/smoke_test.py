#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Smoke-тест пайплайна на ФЕЙКОВОМ Superset (offline, без реального Superset/прода).

Проверяет:
  1) негативные конфиги отклоняются валидатором;
  2) e2e-сборка на фейке проходит;
  3) идемпотентность (двойной прогон → объекты не плодятся);
  4) --dry-run работает офлайн (без прокси).

Запуск:
  python pipeline/tests/smoke_test.py
"""
import copy
import io
import json
import os
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PIPE = os.path.dirname(HERE)
GE = os.path.dirname(PIPE)
os.environ["SUPERSET_PROXY_DIR"] = HERE          # фейковый прокси
sys.path.insert(0, PIPE)

import build_superset as b            # noqa: E402
import superset_session_proxy as stub  # noqa: E402

cfg_path = os.path.join(PIPE, "config.example.generic.json")
cfg = json.load(io.open(cfg_path, encoding="utf-8"))
fails = []


def expect_fail(name, mut):
    c = copy.deepcopy(cfg)
    try:
        mut(c)
    except Exception:
        pass
    try:
        b.validate_config(c)
        fails.append(name)
        print("  FAIL  %-32s не отклонён" % name)
    except SystemExit:
        print("  ok    %-32s отклонён" % name)


print("1) негативные конфиги:")
expect_fail("viz=pie", lambda c: c["charts"][0].__setitem__("viz", "pie"))
expect_fail("дубль chart key", lambda c: c["charts"].append(dict(c["charts"][0])))
expect_fail("битая ссылка чарта", lambda c: c["tabs"][0]["rows"][0][0].__setitem__("chart", "нет"))
expect_fail("фильтр без column", lambda c: c["filters"][0].pop("column"))
expect_fail("env=prod без environments", lambda c: c.__setitem__("env", "prod"))
expect_fail("метрика без col/sql", lambda c: c["charts"][2]["metrics"].__setitem__(0, {"agg": "SUM", "label": "X"}))
expect_fail("agg=DROP", lambda c: c["charts"][2]["metrics"][0].__setitem__("agg", "DROP"))
expect_fail("дубль имени чарта", lambda c: c["charts"][1].__setitem__("name", c["charts"][0]["name"]))
expect_fail("orphan-чарт (нет во вкладках)",
            lambda c: c["charts"].append(dict(c["charts"][0], key="orphan",
                                              name="Orphan X")))
expect_fail("строка вкладки шире 12",
            lambda c: c["tabs"][0]["rows"][0][0].__setitem__("w", 13))
expect_fail("фильтр с пустым datasets",
            lambda c: c["filters"][0].__setitem__("datasets", []))
expect_fail("пустой charts", lambda c: c.__setitem__("charts", []))
expect_fail("пустой tabs", lambda c: c.__setitem__("tabs", []))
expect_fail("dashboard_id не число", lambda c: c.__setitem__("dashboard_id", "abc"))
expect_fail("дубль таблицы датасета", lambda c: c["datasets"].append(dict(c["datasets"][0])))
expect_fail("sql метрики не строка",
            lambda c: c["charts"][2]["metrics"].__setitem__(0, {"sql": {"x": 1}, "label": "S"}))
expect_fail("w отрицательный",
            lambda c: c["tabs"][0]["rows"][0][0].__setitem__("w", -1))
expect_fail("чарт размещён дважды",
            lambda c: c["tabs"][0]["rows"][0].append(dict(c["tabs"][0]["rows"][0][0])))
expect_fail("вкладка без строк",
            lambda c: c["tabs"].append({"name": "Пусто", "rows": []}))
expect_fail("дубль имени фильтра",
            lambda c: c["filters"].append(dict(c["filters"][0])))

print("\n2) e2e + 3) идемпотентность (фейковый Superset):")
tmp = os.path.join(HERE, "_cfg.json")
json.dump(cfg, io.open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
counts = []
for run in (1, 2):
    sys.argv = ["build_superset.py", "--config", tmp]
    b.main()
    counts.append((len(stub.S.ds), len(stub.S.ch)))
print("  run1=%s run2=%s" % (counts[0], counts[1]))
if counts[0] != counts[1]:
    fails.append("идемпотентность")
    print("  FAIL  объекты плодятся между прогонами")
else:
    print("  ok    идемпотентно")

db_posts = [p for (mm, p) in stub.S.calls
            if p == "/api/v1/dashboard/" and mm == "POST"]
if len(stub.S.db) == 1 and len(db_posts) == 1:
    print("  ok    дашборд создан один раз (POST=%d, в сторе=%d)"
          % (len(db_posts), len(stub.S.db)))
else:
    fails.append("дашборд создан не единожды")
    print("  FAIL  дашборд: POST=%d, в сторе=%d" % (len(db_posts), len(stub.S.db)))

print("\n4) --dry-run офлайн (без прокси):")
env = dict(os.environ)
env["SUPERSET_PROXY_DIR"] = os.path.join(HERE, "__none__")
env["PYTHONIOENCODING"] = "utf-8"
r = subprocess.run([sys.executable, os.path.join(PIPE, "build_superset.py"),
                    "--config", cfg_path, "--dry-run"],
                   env=env, capture_output=True, text=True, encoding="utf-8")
if r.returncode == 0 and "конфиг валиден" in (r.stdout or ""):
    print("  ok    dry-run офлайн работает")
else:
    fails.append("dry-run офлайн")
    print("  FAIL  dry-run офлайн: rc=%d %s" % (r.returncode, r.stderr[-200:]))

print("\n5) BOM-конфиг и битый JSON:")


def _run(args, env):
    return subprocess.run([sys.executable] + args, env=env, capture_output=True,
                          text=True, encoding="utf-8")


bom = os.path.join(HERE, "_bom.json")
with io.open(bom, "w", encoding="utf-8-sig") as fh:
    fh.write(json.dumps(cfg, ensure_ascii=False))
r = _run([os.path.join(PIPE, "build_superset.py"), "--config", bom,
          "--dry-run"], env)
if r.returncode == 0:
    print("  ok    BOM-конфиг принят (--dry-run)")
else:
    fails.append("BOM-конфиг")
    print("  FAIL  BOM-конфиг: rc=%d %s" % (r.returncode, r.stderr[-200:]))

bad = os.path.join(HERE, "_bad.json")
with io.open(bad, "w", encoding="utf-8") as fh:
    fh.write("{ не json")
r = _run([os.path.join(PIPE, "build_superset.py"), "--config", bad,
          "--dry-run"], env)
if r.returncode != 0 and "Traceback" not in (r.stderr or ""):
    print("  ok    битый JSON -> понятная ошибка без traceback")
else:
    fails.append("битый JSON")
    print("  FAIL  битый JSON: rc=%d %s" % (r.returncode, r.stderr[-200:]))

print("\n6) HTML-адаптер (нейтральный конфиг):")
for name in ("config.example.generic.json",):
    out = os.path.join(HERE, "_" + name + ".html")
    r = _run([os.path.join(PIPE, "render_html.py"),
              "--config", os.path.join(PIPE, name), "--out", out], env)
    if r.returncode == 0 and os.path.exists(out):
        print("  ok    %s -> HTML" % name)
    else:
        fails.append("render_html %s" % name)
        print("  FAIL  %s: rc=%d %s" % (name, r.returncode, r.stderr[-200:]))

print("\n7) переименование чарта -> нет сироты:")
ren = copy.deepcopy(cfg)
ren["charts"][0]["name"] = ren["charts"][0]["name"] + " (new)"
ren_path = os.path.join(HERE, "_ren.json")
with io.open(ren_path, "w", encoding="utf-8") as fh:
    fh.write(json.dumps(ren, ensure_ascii=False))
before = len(stub.S.ch)
sys.argv = ["build_superset.py", "--config", ren_path]
b.main()
after = len(stub.S.ch)
if after == before:
    print("  ok    чартов %d -> %d (переименование на месте)" % (before, after))
else:
    fails.append("переименование чарта плодит сироту")
    print("  FAIL  чартов %d -> %d" % (before, after))

print("\n8) last-known-good снапшоты (offline):")
import dashboard_state as ds  # noqa: E402
root = os.path.join(HERE, "_state_test")
if os.path.exists(root):
    shutil.rmtree(root)
p1 = ds.save({"a": 1}, 900, {"t": 1}, {"k": 5}, root)
time.sleep(1.1)
p2 = ds.save({"a": 2}, 900, {"t": 1}, {"k": 5}, root)
ls = ds.list_snapshots(900, root)
lb = ds.latest_before(900, root)
lb0 = ds.latest_before(900, root, exclude_fn=p2)
if len(ls) == 2 and lb and lb["fn"] == p2 and lb0 and lb0["fn"] == p1:
    print("  ok    снапшоты: 2 сохранены; latest=последний; latest_before=предыдущий")
else:
    fails.append("dashboard_state")
    print("  FAIL  state: %d снапшотов" % len(ls))
shutil.rmtree(root, ignore_errors=True)

for f in (bom, bad, ren_path):
    if os.path.exists(f):
        os.remove(f)
if os.path.exists(tmp):
    os.remove(tmp)
print("\nИТОГ: %s" % ("ВСЁ OK" if not fails else "ДЕФЕКТЫ: %s" % fails))
sys.exit(0 if not fails else 1)
