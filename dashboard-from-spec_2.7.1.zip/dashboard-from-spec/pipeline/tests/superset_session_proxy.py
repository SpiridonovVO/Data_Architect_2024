"""Фейковый Superset (для offline smoke-тестов). Подменяет superset_session_proxy.
НЕ ходит в реальный Superset/прод."""
import json
import re


class FakeState:
    ds = []
    ch = []
    db = []
    saved = None
    calls = []


S = FakeState


class SupersetSession:
    def login(self):
        pass

    def redirect(self, method, path, h, data):
        S.calls.append((method, path))
        body = json.loads(data) if data else {}

        def J(o, st=200):
            return (st, json.dumps(o).encode(), {})

        if "csrf" in path:
            return J({"result": "x"})
        if path.startswith("/api/v1/dataset/") and method == "GET" and "?q" in path:
            return J({"result": [{"id": d["id"], "schema": d.get("schema"),
                                  "table_name": d.get("table_name"),
                                  "database": {"id": d.get("database")}}
                                 for d in S.ds]})
        if path == "/api/v1/dataset/" and method == "POST":
            body["id"] = len(S.ds) + 100
            S.ds.append(body)
            return J({"id": body["id"]}, 201)
        m = re.match(r"/api/v1/dataset/(\d+)$", path)
        if m and method == "GET":
            return J({"result": {"columns": [{"id": 1, "column_name": "region"}]}})
        if m and method == "PUT":
            return J({"result": {}})
        if path.startswith("/api/v1/chart/?q"):
            return J({"result": [{"id": c["id"], "slice_name": c["slice_name"],
                                  "description": c.get("description", "")}
                                 for c in S.ch]})
        if path == "/api/v1/chart/" and method == "POST":
            body["id"] = len(S.ch) + 500
            S.ch.append(body)
            return J({"id": body["id"]}, 201)
        m = re.match(r"/api/v1/chart/(\d+)$", path)
        if m and method == "GET":
            for c in S.ch:
                if str(c["id"]) == m.group(1):
                    return J({"result": {"dashboards": [
                        x if isinstance(x, dict) else {"id": x}
                        for x in c.get("dashboards", [])]}})
            return J({"message": "not found"}, 404)
        if m and method == "PUT":
            for c in S.ch:
                if str(c["id"]) == m.group(1):
                    old_dashboards = c.get("dashboards", [])
                    c.update(body)
                    if "dashboards" in body:
                        c["dashboards"] = body["dashboards"]
                    elif old_dashboards:
                        c["dashboards"] = old_dashboards
            return J({"result": {}})
        if path.startswith("/api/v1/dashboard/?q"):
            return J({"result": [{"id": d["id"],
                                  "dashboard_title": d.get("dashboard_title")}
                                 for d in S.db]})
        if path == "/api/v1/dashboard/" and method == "POST":
            body["id"] = len(S.db) + 900
            S.db.append(body)
            return J({"id": body["id"]}, 201)
        m = re.match(r"/api/v1/dashboard/(\d+)$", path)
        if m and method == "GET":
            for d in S.db:
                if str(d["id"]) == m.group(1):
                    return J({"result": d})
            return J({"message": "not found"}, 404)
        if m and method == "PUT":
            S.saved = body
            return J({"result": {}})
        return J({"message": "unhandled"}, 404)
