import copy
from datetime import datetime, timedelta, timezone
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import types
from unittest.mock import Mock

import pytest

import build_superset as build
import dashboard_state as state
import dq_checks as dq
import git_ops as git
import promote
import render_html as html
import revert
from conftest import PIPE, ROOT, TEMPLATES

def write_cfg(tmp_path, cfg):
    p = tmp_path / 'config.json'
    p.write_text(json.dumps(cfg, ensure_ascii=False), encoding='utf-8-sig')
    return p

def run_build(monkeypatch, tmp_path, cfg):
    p = write_cfg(tmp_path, cfg)
    monkeypatch.setattr(sys, 'argv', ['build', '--config', str(p)])
    build.main()

@pytest.mark.parametrize('agg', sorted(build.AGG_ENUM))
def test_metric_aggregations(agg):
    assert build.metric({'col': 'revenue', 'agg': agg})['aggregate'] == agg

def test_sql_metric_formula_preserved():
    sql = 'CASE WHEN SUM(orders)>0 THEN SUM(revenue)/SUM(orders) END'
    assert build.metric({'sql': sql})['sqlExpression'] == sql

@pytest.mark.parametrize('mut', [
    lambda c: c.update(charts=[]),
    lambda c: c['charts'][0].update(dataset='absent'),
    lambda c: c['charts'][0].update(metric={'col':'x','sql':'SUM(x)'}),
    lambda c: c['filters'][0].update(default='2025'),
    lambda c: c.update(env='unknown', environments={'test':{}}),
    lambda c: c['charts'][0].update(metric={'col':'x','agg':'DROP'}),
])
def test_invalid_configs_rejected(cfg, mut):
    mut(cfg)
    with pytest.raises(SystemExit):
        build.validate_config(cfg)

@pytest.mark.parametrize('key,value', [('charts',None),('datasets',[None]),('tabs',[None]),('filters',[None]),('charts',{}),('dashboard',None)])
def test_malformed_config_has_controlled_error(cfg, key, value):
    cfg[key] = value
    with pytest.raises((SystemExit, ValueError)):
        build.validate_config(cfg)

@pytest.mark.parametrize('key', ['datasets','charts','tabs','filters'])
def test_config_collection_entries_must_be_objects(cfg,key):
    cfg[key]=[None]
    with pytest.raises(SystemExit):
        build.validate_config(cfg)

def test_schema_rejects_boolean_database_id(cfg):
    cfg['database_id'] = True
    with pytest.raises(SystemExit):
        build.validate_schema(cfg, str(PIPE / 'config.schema.json'))

def test_validator_rejects_boolean_dashboard_id(cfg):
    cfg['dashboard_id']=True
    with pytest.raises(SystemExit):
        build.validate_config(cfg)

def test_environment_overrides(cfg):
    cfg.update(env='test', environments={'test':{'schema':'qa_mart','database_id':7,'title':'QA','env_file':'qa.env','css_template':'qa.css'}})
    got = build.resolve_env(cfg)
    assert (got['schema'],got['database_id'],got['dashboard']['title'],got['superset']['env_file'],got['css_template']) == ('qa_mart',7,'QA','qa.env','qa.css')

def test_env_file_preserves_existing_and_ignores_comment(monkeypatch, tmp_path):
    monkeypatch.setenv('QA_ENV', 'existing')
    p = tmp_path / '.env'
    p.write_text('#comment\nQA_ENV=new\nQA_NEW="value"\n', encoding='utf-8')
    build.load_env_file(str(p))
    import os
    assert os.environ['QA_ENV'] == 'existing' and os.environ['QA_NEW'] == 'value'

def test_e2e_idempotence(fake_superset, cfg, monkeypatch, tmp_path):
    run_build(monkeypatch, tmp_path, cfg)
    run_build(monkeypatch, tmp_path, cfg)
    assert (len(fake_superset.S.ds),len(fake_superset.S.ch),len(fake_superset.S.db)) == (1,6,1)
    saved = fake_superset.S.saved
    assert len(json.loads(saved['json_metadata'])['native_filter_configuration']) == 3
    assert len([v for v in json.loads(saved['position_json']).values() if isinstance(v,dict) and v.get('type')=='CHART']) == 6

def test_second_dashboard_does_not_mutate_first_charts(fake_superset, cfg, monkeypatch, tmp_path):
    run_build(monkeypatch, tmp_path, cfg)
    first = copy.deepcopy(fake_superset.S.ch)
    other = copy.deepcopy(cfg)
    other['dashboard']['title'] = 'Другой заказчик'
    other['schema'] = 'another_mart'
    for chart in other['charts']:
        chart['name'] += ' второго дашборда'
    run_build(monkeypatch, tmp_path, other)
    assert len(fake_superset.S.ch) == 12, 'chart key must be scoped to dashboard/project'
    assert fake_superset.S.ch[:6] == first

def test_legacy_chart_is_migrated_only_when_linked_to_dashboard(fake_superset,cfg,monkeypatch,tmp_path):
    fake_superset.S.db.append({'id':900,'dashboard_title':cfg['dashboard']['title']})
    for i,ch in enumerate(cfg['charts']):
        fake_superset.S.ch.append({'id':500+i,'slice_name':ch['name'],'description':'[dash-key:%s]' % ch['key'],'dashboards':[900]})
    run_build(monkeypatch,tmp_path,cfg)
    assert len(fake_superset.S.ch)==6
    assert all('[dash-key:900:' in ch['description'] for ch in fake_superset.S.ch)

def test_api_error_stops_build_without_snapshot(fake_superset, cfg, monkeypatch, tmp_path):
    from superset_client import Superset
    monkeypatch.setattr(Superset, 'save_dashboard', Mock(side_effect=RuntimeError('HTTP 500')))
    with pytest.raises(RuntimeError):
        run_build(monkeypatch, tmp_path, cfg)
    assert not list((tmp_path / 'state').glob('*.json'))

def test_filter_default_and_deterministic_id():
    from superset_client import Superset
    a = Superset.make_filter('Год','year',[1],['2025'])
    b = Superset.make_filter('Год','year',[1],['2025'])
    assert a == b
    assert a['defaultDataMask']['extraFormData']['filters'][0]['val'] == ['2025']

def test_link_preserves_other_dashboard(monkeypatch):
    from superset_client import Superset
    ss = Superset.__new__(Superset)
    ss.req = Mock(side_effect=[(200,{'result':{'dashboards':[{'id':5}]}}),(200,{})])
    ss.link_chart(3, 7)
    assert ss.req.call_args.args[2]['dashboards'] == [5,7]

def test_dataset_database_isolation():
    from superset_client import Superset
    ss = Superset.__new__(Superset)
    ss._ds_cache = [{'id':1,'schema':'s','table_name':'t','database':{'id':1}}, {'id':2,'schema':'s','table_name':'t','database':{'id':2}}, {'id':3,'schema':'s','table_name':'t','database':None}]
    assert ss.find_dataset('s','t',2)==2
    assert ss.find_dataset('s','t',3) is None

def test_dataset_pagination_and_cache():
    from superset_client import Superset
    ss = Superset.__new__(Superset)
    ss._ds_cache = None
    ss.req = Mock(side_effect=[(200,{'result':[{'id':n} for n in range(100)]}), (200,{'result':[{'id':100}]})])
    assert len(ss._datasets()) == 101
    assert len(ss._datasets()) == 101 and ss.req.call_count == 2

def test_state_retains_ten(monkeypatch,tmp_path):
    for i in range(12):
        monkeypatch.setattr(state.time,'strftime',lambda fmt, i=i: '20261009_%06d' % i)
        state.save({'v':i},42,{}, {},str(tmp_path))
    snaps=state.list_snapshots(42,str(tmp_path))
    assert len(snaps)==10
    assert sorted(s['config']['v'] for s in snaps)==list(range(2,12))

def test_state_save_is_unique_within_second(monkeypatch,tmp_path):
    monkeypatch.setattr(state.time,'strftime',lambda fmt:'20261009_100000')
    state.save({'v':1},42,{}, {},str(tmp_path))
    state.save({'v':2},42,{}, {},str(tmp_path))
    assert len(state.list_snapshots(42,str(tmp_path))) == 2

@pytest.mark.parametrize('step,expected', [(1,2),(2,1)])
def test_revert_steps_select_previous(monkeypatch,tmp_path,cfg,step,expected):
    snaps=[{'ts':n,'config':dict(cfg,version=n)} for n in (1,2,3)]
    monkeypatch.setattr(state,'list_snapshots',lambda *a:snaps)
    runner=Mock(return_value=subprocess.CompletedProcess([],0))
    monkeypatch.setattr(revert.subprocess,'run',runner)
    p=tmp_path/'revert.json'
    monkeypatch.setattr(sys,'argv',['revert','--dash-id','42','--step',str(step),'--yes','--out',str(p)])
    revert.main()
    assert json.loads(p.read_text(encoding='utf-8'))['version']==expected

@pytest.mark.parametrize('step',[0,-1,100])
def test_revert_invalid_step_controlled(monkeypatch,tmp_path,cfg,step):
    monkeypatch.setattr(state,'list_snapshots',lambda *a:[{'ts':1,'config':cfg}])
    monkeypatch.setattr(revert.subprocess,'run',Mock(return_value=subprocess.CompletedProcess([],0)))
    monkeypatch.setattr(sys,'argv',['revert','--dash-id','42','--step',str(step),'--yes','--out',str(tmp_path/'r.json')])
    with pytest.raises(SystemExit):
        revert.main()

def test_revert_to_test_changes_config_and_proxy(monkeypatch,tmp_path,cfg):
    cfg.update(env='prod',environments={'test':{'superset_proxy_dir':str(PIPE/'tests')},'prod':{'superset_proxy_dir':'do-not-use'}})
    monkeypatch.setattr(state,'list_snapshots',lambda *a:[{'ts':1,'config':cfg},{'ts':2,'config':cfg}])
    runner=Mock(return_value=subprocess.CompletedProcess([],0))
    monkeypatch.setattr(revert.subprocess,'run',runner)
    out=tmp_path/'revert.json'
    monkeypatch.setattr(sys,'argv',['revert','--dash-id','42','--to','test','--yes','--out',str(out)])
    revert.main()
    assert json.loads(out.read_text(encoding='utf-8'))['env']=='test'
    assert runner.call_args.kwargs['env']['SUPERSET_PROXY_DIR']==str(PIPE/'tests')

def test_revert_prod_requires_confirmation(monkeypatch,cfg):
    monkeypatch.setattr(state,'list_snapshots',lambda *a:[{'ts':1,'config':cfg}])
    runner=Mock()
    monkeypatch.setattr(revert.subprocess,'run',runner)
    monkeypatch.setattr(sys,'argv',['revert','--dash-id','42','--to','prod','--yes'])
    with pytest.raises(SystemExit,match='PROMOTE_ALLOW_PROD'):
        revert.main()
    runner.assert_not_called()

@pytest.mark.parametrize('field', ['superset_proxy_dir','superset_url'])
def test_promote_refuses_same_prod_destination(monkeypatch,tmp_path,cfg,field):
    cfg['environments']={'test':{'superset_proxy_dir':'test-proxy','superset_url':'test-url'},'prod':{'superset_proxy_dir':'prod-proxy','superset_url':'prod-url'}}
    cfg['environments']['test'][field]=cfg['environments']['prod'][field]
    p=write_cfg(tmp_path,cfg)
    runner=Mock()
    monkeypatch.setattr(promote,'run',runner)
    monkeypatch.setattr(sys,'argv',['promote','--config',str(p),'--to','test','--yes'])
    with pytest.raises(SystemExit,match='прод'):
        promote.main()
    runner.assert_not_called()

def test_promote_prod_requires_flag(monkeypatch,tmp_path,cfg):
    cfg['environments']={'prod':{'superset_proxy_dir':'do-not-use'}}
    p=write_cfg(tmp_path,cfg)
    monkeypatch.setattr(sys,'argv',['promote','--config',str(p),'--to','prod','--yes'])
    with pytest.raises(SystemExit,match='PROMOTE_ALLOW_PROD'):
        promote.main()

def test_promote_vars_cannot_override_validated_proxy(monkeypatch,tmp_path,cfg):
    cfg['environments']={'test':{'superset_proxy_dir':str(PIPE/'tests'),'vars':{'SUPERSET_PROXY_DIR':'do-not-use-prod-proxy'}},'prod':{'superset_proxy_dir':'do-not-use-prod-proxy'}}
    p=write_cfg(tmp_path,cfg)
    runner=Mock()
    monkeypatch.setattr(promote,'run',runner)
    monkeypatch.setattr(sys,'argv',['promote','--config',str(p),'--to','test','--yes'])
    with pytest.raises(SystemExit,match='зарезервирована'):
        promote.main()
    runner.assert_not_called()

def test_promote_equivalent_proxy_paths_rejected(monkeypatch,tmp_path,cfg):
    cfg['environments']={'test':{'superset_proxy_dir':str(PIPE/'tests'/'.')+'\\.'},'prod':{'superset_proxy_dir':str(PIPE/'tests')}}
    p=write_cfg(tmp_path,cfg)
    monkeypatch.setattr(promote,'run',Mock())
    monkeypatch.setattr(sys,'argv',['promote','--config',str(p),'--to','test','--yes'])
    with pytest.raises(SystemExit):
        promote.main()

def test_promote_normalizes_url_before_environment_comparison(monkeypatch,tmp_path,cfg):
    cfg['environments']={'test':{'superset_proxy_dir':'test-proxy','superset_url':'https://BI.example/test/'},'prod':{'superset_proxy_dir':'prod-proxy','superset_url':'https://bi.example/test'}}
    p=write_cfg(tmp_path,cfg)
    monkeypatch.setattr(promote,'run',Mock())
    monkeypatch.setattr(sys,'argv',['promote','--config',str(p),'--to','test','--yes'])
    with pytest.raises(SystemExit,match='прод-URL'):
        promote.main()

def test_revert_pins_requested_dashboard_id(monkeypatch,tmp_path,cfg):
    monkeypatch.setattr(state,'list_snapshots',lambda *a:[{'ts':1,'config':cfg},{'ts':2,'config':cfg}])
    monkeypatch.setattr(revert.subprocess,'run',Mock(return_value=subprocess.CompletedProcess([],0)))
    out=tmp_path/'r.json'
    monkeypatch.setattr(sys,'argv',['revert','--dash-id','42','--yes','--out',str(out)])
    revert.main()
    assert json.loads(out.read_text(encoding='utf-8')).get('dashboard_id')==42

def test_promote_failure_does_not_change_env(monkeypatch,tmp_path,cfg):
    cfg.update(env='old',environments={'test':{'superset_proxy_dir':str(PIPE/'tests')}})
    p=write_cfg(tmp_path,cfg)
    monkeypatch.setattr(promote,'run',Mock(side_effect=SystemExit('step failed')))
    monkeypatch.setattr(sys,'argv',['promote','--config',str(p),'--to','test','--yes'])
    with pytest.raises(SystemExit):
        promote.main()
    assert json.loads(p.read_text(encoding='utf-8-sig'))['env']=='old'
    assert not Path(str(p)+'.run').exists()

def test_promote_gate_steps_builder_and_variables(monkeypatch,tmp_path,cfg):
    cfg['environments']={'test':{'superset_proxy_dir':str(PIPE/'tests'),'vars':{'QA_MARKER':'test'},'gate':[['python','dq.py']],'steps':[['python','loader.py']]}}
    p=write_cfg(tmp_path,cfg)
    runner=Mock()
    monkeypatch.setattr(promote,'run',runner)
    monkeypatch.setattr(sys,'argv',['promote','--config',str(p),'--to','test','--yes'])
    promote.main()
    assert [c.args[0][1] for c in runner.call_args_list[:2]]==['dq.py','loader.py']
    assert runner.call_args_list[0].kwargs['env']['QA_MARKER']=='test'
    assert json.loads(p.read_text(encoding='utf-8'))['env']=='test'

@pytest.mark.parametrize('cmd',[['powershell','-Command','no'],['python','-c','no']])
def test_promote_blocks_unapproved_command(cmd):
    with pytest.raises(SystemExit):
        promote.run(cmd)

def test_html_escapes_untrusted_text(cfg):
    cfg['dashboard']['title']='<script>alert(1)</script>'
    page=html.render(cfg,{})
    assert '<script>alert(1)</script>' not in page
    assert '&lt;script&gt;' in page

def test_html_default_filter(cfg):
    cfg['filters'][0]['default']=['2025']
    page=html.render(cfg,{'rows':{'bar_rev_year':[{'year':'2025','Выручка':10}]}})
    assert 'selected' in page

def test_html_line_preserves_visual_type(cfg):
    result=html.widget(cfg['charts'][3],{'rows':{'line_avg_year':[{'year':'2025','Средний чек':10}]}})
    assert 'class="bars"' not in result

def test_html_table_column_name_fallback(cfg):
    result=html.widget(cfg['charts'][5],{'rows':{'table_region':[{'region':'Москва','year':'2025','revenue':314159,'orders':12,'Средний чек':1}]}})
    assert '314159' in result

def test_html_missing_metric_is_not_silent_zero(cfg):
    with pytest.raises((ValueError,SystemExit)):
        html.widget(cfg['charts'][2],{'rows':{'bar_rev_year':[{'year':'2025','misspelled':999}]}})

def test_html_honors_multiple_metrics(cfg):
    chart=copy.deepcopy(cfg['charts'][2])
    chart['metrics'].append({'col':'orders','label':'Заказы','agg':'SUM'})
    result=html.widget(chart,{'rows':{chart['key']:[{'year':'2025','Выручка':123,'Заказы':456}]}})
    assert '123' in result and '456' in result
    assert 'series-legend' in result and 'Заказы' in result

def test_html_recomputes_kpi_from_rows(cfg):
    chart=cfg['charts'][0]
    rendered=html.widget(chart,{'values':{chart['key']:999},'rows':{chart['key']:[{'region':'A','revenue':10},{'region':'B','revenue':20}] }},['region'])
    assert 'data-kpi="bn_revenue"' in rendered and 'data-rows=' in rendered

def test_html_has_line_svg_and_accessible_tabs(cfg):
    page=html.render(cfg,{'rows':{'line_avg_year':[{'year':2025,'Средний чек':80}]}})
    assert '<svg class="line-chart"' in page
    assert 'role="tab"' in page and 'aria-selected="true"' in page
    assert 'name="viewport"' in page

def test_html_filter_marks_absent_filter_columns(cfg):
    chart=cfg['charts'][3]
    rendered=html.widget(chart,{'rows':{chart['key']:[{'year':2025,'Средний чек':80}]}},['region'])
    assert 'data-f="{&quot;region&quot;: null}"' in rendered

@pytest.mark.parametrize('invalid',['x;DROP TABLE t','t--','a.b.c','t\n',''])
def test_dq_identifier_rejects_invalid(invalid):
    with pytest.raises(ValueError):
        dq._ident(invalid)

@pytest.mark.parametrize('vals,expected', [(['2025-01','2025-03'],['2025-02']),(['2024-12','2025-02'],['2025-01']),(['2025-01','2025-01'],[])])
def test_dq_period_gaps(vals,expected):
    if vals == ['garbage'] or vals == ['2025-13']:
        with pytest.raises(ValueError):
            dq._find_gaps(vals)
    else:
        assert dq._find_gaps(vals)==expected

@pytest.mark.parametrize('vals',[[],['garbage'],['2025-13']])
def test_dq_invalid_period_is_not_green(vals):
    cur=Mock()
    cur.__enter__=Mock(return_value=cur)
    cur.__exit__=Mock(return_value=False)
    cur.fetchall.return_value=[(v,) for v in vals]
    cn=Mock()
    cn.cursor.return_value=cur
    with pytest.raises(dq.DQError):
        dq.run_checks(cn,[{'kind':'period_continuous','table':'qa.fact','period':'month'}])

@pytest.mark.parametrize('kind,result,ok', [('not_empty',1,True),('not_empty',0,False),('sum_eq',100,True),('sum_eq',99,False),('no_dupes',0,True),('no_dupes',1,False),('no_nulls',0,True),('no_nulls',1,False)])
def test_dq_checks_positive_negative(kind,result,ok):
    cur=Mock()
    cur.__enter__=Mock(return_value=cur)
    cur.__exit__=Mock(return_value=False)
    cur.fetchone.return_value=(result,)
    cn=Mock()
    cn.cursor.return_value=cur
    check={'kind':kind,'table':'qa.fact','column':'amount','expected':100,'keys':['id'],'columns':['id']}
    if ok:
        assert dq.run_checks(cn,[check])[0][3]
    else:
        with pytest.raises(dq.DQError):
            dq.run_checks(cn,[check])

@pytest.mark.parametrize('status,message,ok', [(201,{},True),(400,'Branch already exists',True),(400,'invalid reference',False),(403,'Forbidden',False)])
def test_git_branch_errors(monkeypatch,status,message,ok):
    monkeypatch.setattr(git,'_api',lambda *a:(status,message))
    if status==400 and not ok:
        with pytest.raises(SystemExit):
            git.create_branch('qa')
    else:
        assert git.create_branch('qa') is ok

@pytest.mark.parametrize('value,expected',[('123','123'),('group/project','group%2Fproject'),('group%2Fproject','group%2Fproject')])
def test_git_project_encoding(monkeypatch,value,expected):
    monkeypatch.setattr(git,'PROJECT',value)
    assert git._proj_id()==expected

def test_git_no_mr_after_commit_failure(monkeypatch,tmp_path):
    p=tmp_path/'x.py'
    p.write_text('pass',encoding='utf-8')
    monkeypatch.setattr(git,'create_branch',lambda *a,**k:True)
    monkeypatch.setattr(git,'commit_files',lambda *a,**k:False)
    mr=Mock()
    monkeypatch.setattr(git,'create_mr',mr)
    with pytest.raises(SystemExit):
        git.push_dag('qa',str(p),str(p))
    mr.assert_not_called()

def test_git_lookup_500_not_treated_as_missing(monkeypatch):
    monkeypatch.setattr(git,'_api',lambda *a:(500,'upstream error'))
    with pytest.raises(SystemExit):
        git._file_exists('qa','file.py')

def test_backup_atomic_and_error_cleanup(monkeypatch,tmp_path):
    import db_backup as backup
    def write(cmd,**kwargs):
        Path(cmd[-1]).write_text('Schema: qa',encoding='utf-8')
    monkeypatch.setattr(backup.subprocess,'run',write)
    p=backup.backup('qa',str(tmp_path))
    assert Path(p).exists() and not list(tmp_path.glob('*.tmp'))
    def broken(cmd,**kwargs):
        Path(cmd[-1]).write_text('partial',encoding='utf-8')
        raise RuntimeError('interrupted')
    monkeypatch.setattr(backup.subprocess,'run',broken)
    with pytest.raises(RuntimeError):
        backup.backup('broken',str(tmp_path))
    assert not list(tmp_path.glob('broken*'))

@pytest.mark.parametrize('header',['Schema: another','SELECT 1;','Schema: qa\nSchema: another'])
def test_restore_must_confirm_only_requested_schema(monkeypatch,tmp_path,header):
    import db_backup as backup
    p=tmp_path/'dump.sql'
    p.write_text(header,encoding='utf-8')
    runner=Mock()
    monkeypatch.setattr(backup.subprocess,'run',runner)
    with pytest.raises(SystemExit):
        backup.restore(str(p),'qa')
    runner.assert_not_called()

def test_restore_scans_whole_dump_and_rejects_mixed_schemas(monkeypatch,tmp_path):
    import db_backup as backup
    p=tmp_path/'mixed.sql'
    p.write_text('-- '+('x'*600000)+'\nCREATE SCHEMA qa;\nCREATE SCHEMA other;\n',encoding='utf-8')
    runner=Mock()
    monkeypatch.setattr(backup.subprocess,'run',runner)
    with pytest.raises(SystemExit):
        backup.restore(str(p),'qa')
    runner.assert_not_called()

def test_restore_accepts_only_expected_single_schema(monkeypatch,tmp_path):
    import db_backup as backup
    p=tmp_path/'qa.sql'
    p.write_text('-- pg_dump\nCREATE SCHEMA qa;\n',encoding='utf-8')
    runner=Mock()
    monkeypatch.setattr(backup.subprocess,'run',runner)
    backup.restore(str(p),'qa')
    runner.assert_called_once()

@pytest.mark.parametrize('age,expected',[(1,0),(40,2),(None,1)])
def test_freshness_codes(monkeypatch,age,expected):
    import freshness_check as fresh
    cur=Mock()
    cur.__enter__=Mock(return_value=cur)
    cur.__exit__=Mock(return_value=False)
    cur.fetchone.return_value=(datetime.now(timezone.utc)-timedelta(hours=age) if age is not None else None,)
    cn=Mock()
    cn.cursor.return_value=cur
    monkeypatch.setattr(fresh.psycopg2,'connect',lambda **k:cn)
    for k in ('DB_HOST','DB_USER','DB_PASS'):
        monkeypatch.setenv(k,'fake')
    monkeypatch.setattr(sys,'argv',['fresh','--table','qa.fact'])
    with pytest.raises(SystemExit) as err:
        fresh.main()
    assert err.value.code==expected
    cn.close.assert_called_once()

def test_freshness_closes_on_query_error(monkeypatch):
    import freshness_check as fresh
    cn=Mock()
    cn.cursor.side_effect=RuntimeError('query error')
    monkeypatch.setattr(fresh.psycopg2,'connect',lambda **k:cn)
    for k in ('DB_HOST','DB_USER','DB_PASS'):
        monkeypatch.setenv(k,'fake')
    monkeypatch.setattr(sys,'argv',['fresh','--table','qa.fact'])
    with pytest.raises(RuntimeError):
        fresh.main()
    cn.close.assert_called_once()

def load_fake_dag(monkeypatch):
    tasks={}
    edges=[]
    variables={}
    class Task:
        def __init__(self,name): self.name=name
        def __rshift__(self,other): edges.append((self.name,other.name)); return other
    def task(fn):
        tasks[fn.__name__]=fn
        return lambda: Task(fn.__name__)
    def dag(**kwargs):
        return lambda fn: fn
    pendulum=types.ModuleType('pendulum')
    pendulum.datetime=lambda *a,**k:datetime(2026,1,1)
    pendulum.duration=lambda **k:timedelta(**k)
    decorators=types.ModuleType('airflow.decorators')
    decorators.dag=dag
    decorators.task=task
    models=types.ModuleType('airflow.models')
    models.Variable=types.SimpleNamespace(get=lambda key,default_var=None:variables.get(key,default_var))
    for name,module in [('pendulum',pendulum),('airflow',types.ModuleType('airflow')),('airflow.decorators',decorators),('airflow.models',models)]:
        monkeypatch.setitem(sys.modules,name,module)
    spec=importlib.util.spec_from_file_location('qa_dag',TEMPLATES/'dag.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module,tasks,edges,variables

def test_dag_dependencies(monkeypatch):
    module,tasks,edges,variables=load_fake_dag(monkeypatch)
    assert edges==[('run_loader','run_dq'),('run_dq','verify')]

def test_dag_missing_dq_must_fail(monkeypatch):
    module,tasks,edges,variables=load_fake_dag(monkeypatch)
    with pytest.raises((ValueError,RuntimeError)):
        tasks['run_dq']()

def test_dag_missing_dq_can_be_explicitly_optional(monkeypatch):
    module,tasks,edges,variables=load_fake_dag(monkeypatch)
    variables['dash_dq_required']='false'
    assert tasks['run_dq']() is None

def test_dag_required_credentials(monkeypatch):
    module,tasks,edges,variables=load_fake_dag(monkeypatch)
    with pytest.raises(ValueError,match='креды'):
        module._creds()

def test_dag_load_and_dq_environment(monkeypatch):
    module,tasks,edges,variables=load_fake_dag(monkeypatch)
    variables.update({'dash_db_host':'fake','dash_db_user':'fake','dash_db_pass':'not-a-real-secret','dash_dq_config':'dq.json','dash_load_method':'UPSERT','dash_target_schema':'qa'})
    runner=Mock(return_value=types.SimpleNamespace(stdout='ok'))
    monkeypatch.setattr(module.subprocess,'run',runner)
    tasks['run_loader']()
    tasks['run_dq']()
    assert runner.call_args_list[0].kwargs['env']['LOAD_METHOD']=='UPSERT'
    assert runner.call_args_list[1].kwargs['env']['DQ_CONFIG']=='dq.json'
    assert runner.call_args.kwargs['env']['DB_SSLMODE']=='require'

def test_css_preserves_metadata(monkeypatch):
    import apply_dit_css as css
    res={'position_json':json.dumps({'MARKDOWN-0':{'type':'MARKDOWN'}}),'json_metadata':'{}','dashboard_title':'QA','published':False,'css':''}
    req=Mock(side_effect=[(200,{'result':res}),(200,{})])
    assert css.apply(req,42)
    body=req.call_args.args[2]
    assert body['published'] is False and body['json_metadata']=='{}'
    assert '#MARKDOWN-0' in body['css']

def test_css_uses_configured_superset_base_url(monkeypatch):
    import apply_dit_css as css
    import superset_session_proxy as proxy
    calls=[]
    class Session:
        def login(self): pass
        def redirect(self,method,path,headers,data):
            calls.append((method,path,headers,data))
            body=b'{"result":"csrf"}' if 'csrf_token' in path else b'{}'
            return 200,body,{}
    monkeypatch.setattr(proxy,'SupersetSession',Session)
    monkeypatch.setenv('SUPERSET_URL','https://test.example/base/')
    req=css.api()
    req('GET','/api/v1/dashboard/42')
    assert calls[-1][2]['Referer']=='https://test.example/base/'
