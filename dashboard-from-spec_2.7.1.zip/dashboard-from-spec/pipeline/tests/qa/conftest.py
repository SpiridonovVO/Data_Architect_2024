import importlib
import os
from pathlib import Path
import sys
from unittest.mock import Mock

import pytest

ROOT = next(parent for parent in Path(__file__).resolve().parents
            if (parent / 'pipeline').is_dir() and (parent / 'skill').is_dir())
PIPE = ROOT / 'pipeline'
TEMPLATES = ROOT / 'skill' / 'templates'
sys.path[:0] = [str(PIPE), str(PIPE / 'tests'), str(TEMPLATES)]
os.environ['SUPERSET_PROXY_DIR'] = str(PIPE / 'tests')
os.environ['SUPERSET_URL'] = 'http://127.0.0.1:1'

@pytest.fixture(autouse=True)
def isolate(monkeypatch):
    import urllib.request
    monkeypatch.setattr(urllib.request, 'urlopen', Mock(side_effect=AssertionError('Network disabled in offline tests')))
    monkeypatch.delenv('PROMOTE_ALLOW_PROD', raising=False)
    monkeypatch.delenv('PROMOTE_ALLOW_RCE', raising=False)

@pytest.fixture
def cfg():
    import json
    return json.loads((PIPE / 'config.example.generic.json').read_text(encoding='utf-8-sig'))

@pytest.fixture
def loader(monkeypatch):
    for key in ('TARGET_SCHEMA', 'TARGET_TABLE', 'LOAD_METHOD', 'KEY_COLS', 'COLUMNS', 'CURSOR_COL', 'DDL_ENV', 'PARTITION', 'ALLOW_EMPTY_FULL'):
        monkeypatch.delenv(key, raising=False)
    import loader
    return importlib.reload(loader)

@pytest.fixture
def fake_superset(monkeypatch, tmp_path):
    import superset_session_proxy as stub
    import dashboard_state
    for name in ('ds', 'ch', 'db', 'calls'):
        monkeypatch.setattr(stub.S, name, [])
    monkeypatch.setattr(stub.S, 'saved', None)
    original = dashboard_state.save
    monkeypatch.setattr(dashboard_state, 'save', lambda cfg, did, ds, ch, root: original(cfg, did, ds, ch, str(tmp_path)))
    return stub
