import os
from pathlib import Path
import shutil
import subprocess
import uuid

import psycopg2
from psycopg2 import sql
import pytest

import dq_checks as dq
import json
import sys

DSN=os.environ.get('QA_POSTGRES_DSN')
pytestmark=pytest.mark.skipif(not DSN,reason='Isolated PostgreSQL not available')

@pytest.fixture
def pg(loader,monkeypatch):
    cn=psycopg2.connect(DSN)
    schema='qa_'+uuid.uuid4().hex[:12]
    monkeypatch.setattr(loader,'SCHEMA',schema)
    monkeypatch.setattr(loader,'TABLE','fact')
    monkeypatch.setattr(loader,'DDL',loader.DDL.replace('project_metrics',schema).replace('fact_example','fact'))
    loader.ensure_schema_table(cn)
    try:
        yield cn,schema,loader
    finally:
        if cn.closed:
            cn=psycopg2.connect(DSN)
        cn.rollback()
        with cn.cursor() as cur:
            cur.execute(sql.SQL('DROP SCHEMA {} CASCADE').format(sql.Identifier(schema)))
        cn.commit()
        cn.close()

def select(cn,schema):
    with cn.cursor() as cur:
        cur.execute(sql.SQL('SELECT id,payload FROM {}.fact ORDER BY id').format(sql.Identifier(schema)))
        return cur.fetchall()

@pytest.mark.parametrize('method',['FULL','INC','UPSERT','DELTA','APPEND','SNAPSHOT'])
def test_real_sql_methods(pg,monkeypatch,method):
    cn,schema,loader=pg
    monkeypatch.setattr(loader,'LOAD_METHOD',method)
    assert loader.load(cn,[('1','2025-01-01','{"v":1}')])==1
    assert select(cn,schema)==[('1',{'v':1})]
    if method!='APPEND':
        loader.load(cn,[('1','2025-01-02','{"v":2}')])
        assert select(cn,schema)==[('1',{'v':2})]

def test_full_bad_rows_rollback_preserves_old(pg,monkeypatch):
    cn,schema,loader=pg
    loader.load(cn,[('old','2025-01-01','{}')])
    monkeypatch.setattr(loader,'LOAD_METHOD','FULL')
    with pytest.raises(psycopg2.Error):
        loader.load(cn,[('new','not-a-date','{}')])
    cn.rollback()
    assert select(cn,schema)==[('old',{})]

def test_full_empty_preserves_existing(pg,monkeypatch):
    cn,schema,loader=pg
    loader.load(cn,[('old','2025-01-01','{}')])
    monkeypatch.setattr(loader,'LOAD_METHOD','FULL')
    loader.load(cn,[])
    assert select(cn,schema)==[('old',{})]

def test_partition_replacement_preserves_other_partition(pg,monkeypatch):
    cn,schema,loader=pg
    monkeypatch.setattr(loader,'COLUMNS',['id','updated_at','payload','partition_key'])
    loader.load(cn,[('a','2025-01-01','{}','jan'),('b','2025-02-01','{}','feb')])
    monkeypatch.setattr(loader,'LOAD_METHOD','PARTREPL')
    monkeypatch.setenv('PARTITION','jan')
    loader.load(cn,[('c','2025-01-02','{}','jan')])
    assert select(cn,schema)==[('b',{}),('c',{})]

def test_watermark_roundtrip(pg):
    cn,schema,loader=pg
    assert loader.read_cursor(cn) is None
    loader.save_cursor(cn,'2025-01-01T00:00:00Z')
    assert loader.read_cursor(cn)=='2025-01-01T00:00:00Z'

def test_dq_on_real_tables(pg):
    cn,schema,loader=pg
    loader.load(cn,[('1','2025-01-01','{}'),('2','2025-02-01','{}')])
    table=schema+'.fact'
    checks=[{'kind':'not_empty','table':table}, {'kind':'no_nulls','table':table,'columns':['id','updated_at']}, {'kind':'no_dupes','table':table,'keys':['id']}, {'kind':'period_continuous','table':table,'period':'updated_at'}]
    assert len(dq.run_checks(cn,checks))==4

def test_dq_sum_real(pg):
    cn,schema,loader=pg
    with cn.cursor() as cur:
        cur.execute(sql.SQL('CREATE TABLE {}.amounts(id int,amount numeric); INSERT INTO {}.amounts VALUES (1,10),(2,20)').format(sql.Identifier(schema),sql.Identifier(schema)))
    cn.commit()
    assert dq.run_checks(cn,[{'kind':'sum_eq','table':schema+'.amounts','column':'amount','expected':30}])[0][3]
    with pytest.raises(dq.DQError):
        dq.run_checks(cn,[{'kind':'sum_eq','table':schema+'.amounts','column':'amount','expected':31}])

def test_dq_detects_nulls_dupes_gaps(pg):
    cn,schema,loader=pg
    with cn.cursor() as cur:
        cur.execute(sql.SQL("CREATE TABLE {}.bad(id int,month date); INSERT INTO {}.bad VALUES (1,'2025-01-01'),(1,'2025-03-01'),(NULL,NULL)").format(sql.Identifier(schema),sql.Identifier(schema)))
    cn.commit()
    for c in [{'kind':'no_nulls','columns':['id']},{'kind':'no_dupes','keys':['id']},{'kind':'period_continuous','period':'month'}]:
        with pytest.raises(dq.DQError):
            dq.run_checks(cn,[dict(c,table=schema+'.bad')])

def test_default_snapshot_explicitly_warns_that_history_is_overwritten(pg,monkeypatch,caplog):
    cn,schema,loader=pg
    monkeypatch.setattr(loader,'LOAD_METHOD','SNAPSHOT')
    monkeypatch.setattr(loader.time,'strftime',lambda fmt,*args:'2025-01-01')
    loader.load(cn,[('1','2025-01-01','{"v":1}')])
    monkeypatch.setattr(loader.time,'strftime',lambda fmt,*args:'2025-01-02')
    loader.load(cn,[('1','2025-01-02','{"v":2}')])
    assert len(select(cn,schema))==1
    assert 'история перезаписывается' in caplog.text

def test_documented_snapshot_composite_key_configuration(pg,monkeypatch):
    cn,schema,loader=pg
    with cn.cursor() as cur:
        cur.execute(sql.SQL('ALTER TABLE {}.fact DROP CONSTRAINT fact_pkey; ALTER TABLE {}.fact ADD PRIMARY KEY(id,snapshot_date)').format(sql.Identifier(schema),sql.Identifier(schema)))
        cur.execute(sql.SQL('ALTER TABLE {}.fact ALTER COLUMN snapshot_date SET NOT NULL').format(sql.Identifier(schema)))
    cn.commit()
    monkeypatch.setattr(loader,'LOAD_METHOD','SNAPSHOT')
    monkeypatch.setattr(loader,'COLUMNS',['id','updated_at','payload','snapshot_date'])
    monkeypatch.setattr(loader,'KEY_COLS',['id','snapshot_date'])
    monkeypatch.setattr(loader.time,'strftime',lambda fmt,*args:'2025-01-01')
    loader.load(cn,[('1','2025-01-01','{}','ignored')])
    monkeypatch.setattr(loader.time,'strftime',lambda fmt,*args:'2025-01-02')
    loader.load(cn,[('1','2025-01-02','{}','ignored')])
    with cn.cursor() as cur:
        cur.execute(sql.SQL('SELECT count(*) FROM {}.fact').format(sql.Identifier(schema)))
        assert cur.fetchone()[0]==2

def test_watermark_failure_rolls_back_loaded_rows(pg,monkeypatch):
    cn,schema,loader=pg
    monkeypatch.setattr(loader,'connect',lambda:cn)
    monkeypatch.setattr(loader,'extract',lambda c:([('1','2025-01-01','{}')],'new'))
    def fail(cn,cursor,commit=True): raise RuntimeError('watermark failed')
    monkeypatch.setattr(loader,'save_cursor',fail)
    with pytest.raises(RuntimeError):
        loader.main()
    check=psycopg2.connect(DSN)
    try:
        assert select(check,schema)==[], 'data already committed before watermark; transaction not atomic'
    finally:
        check.close()

def test_declared_custom_columns_work_with_custom_ddl(pg,monkeypatch,tmp_path):
    cn,schema,loader=pg
    with cn.cursor() as cur:
        cur.execute(sql.SQL('DROP TABLE {}.fact').format(sql.Identifier(schema)))
    cn.commit()
    custom_ddl=tmp_path/'custom-ddl.sql'
    custom_ddl.write_text('CREATE TABLE "%s"."fact" (id text PRIMARY KEY, amount numeric, loaded_at timestamptz DEFAULT now());' % schema,encoding='utf-8')
    monkeypatch.setenv('DDL_ENV',str(custom_ddl))
    loader.ensure_schema_table(cn)
    monkeypatch.setattr(loader,'COLUMNS',['id','amount'])
    loader.load(cn,[('1',42)])
    with cn.cursor() as cur:
        cur.execute(sql.SQL('SELECT amount FROM {}.fact').format(sql.Identifier(schema)))
        assert cur.fetchone()[0]==42

def test_real_backup_restore_roundtrip(pg,monkeypatch,tmp_path):
    import db_backup as backup
    if not shutil.which('pg_dump') or not shutil.which('psql'):
        pytest.skip('pg_dump and psql are required for the real backup/restore roundtrip')
    cn,schema,loader=pg
    loader.load(cn,[('1','2025-01-01','{"amount":42}')])
    parts=psycopg2.extensions.parse_dsn(DSN)
    for name,key in [('HOST','host'),('PORT','port'),('USER','user'),('NAME','dbname')]:
        monkeypatch.setattr(backup,name,parts[key])
    monkeypatch.setattr(backup,'ENV',dict(os.environ,PGPASSWORD=parts['password']))
    dump=backup.backup(schema,str(tmp_path))
    assert Path(dump).exists() and not list(tmp_path.glob('*.tmp'))
    with cn.cursor() as cur:
        cur.execute(sql.SQL('DROP SCHEMA {} CASCADE').format(sql.Identifier(schema)))
    cn.commit()
    backup.restore(dump,schema)
    assert select(cn,schema)==[('1',{'amount':42})]

def test_integrated_source_to_db_dq_fake_bi_html(pg,monkeypatch,tmp_path,cfg,fake_superset):
    import build_superset as build
    import render_html
    cn,schema,loader=pg
    # Synthetic source adapter: shipped extract() is intentionally a placeholder.
    facts=[('1','2025-01-01',json.dumps({'region':'Москва','year':2025,'revenue':100,'orders':2})),('2','2025-01-02',json.dumps({'region':'МО','year':2025,'revenue':300,'orders':3}))]
    assert loader.load(cn,facts)==2
    with cn.cursor() as cur:
        cur.execute(sql.SQL("CREATE VIEW {}.v_sales AS SELECT payload->>'region' AS region,(payload->>'year')::int AS year,sum((payload->>'revenue')::numeric) AS revenue,sum((payload->>'orders')::numeric) AS orders,sum((payload->>'revenue')::numeric)/NULLIF(sum((payload->>'orders')::numeric),0) AS avg_check FROM {}.fact GROUP BY 1,2").format(sql.Identifier(schema),sql.Identifier(schema)))
    cn.commit()
    checks=[{'kind':'not_empty','table':schema+'.v_sales'},{'kind':'sum_eq','table':schema+'.v_sales','column':'revenue','expected':400},{'kind':'sum_eq','table':schema+'.v_sales','column':'orders','expected':5}]
    assert len(dq.run_checks(cn,checks))==3
    with cn.cursor() as cur:
        cur.execute(sql.SQL('SELECT region,year,revenue,orders,avg_check FROM {}.v_sales ORDER BY region').format(sql.Identifier(schema)))
        rows=[{'region':r[0],'year':r[1],'Выручка':float(r[2]),'Заказов':float(r[3]),'Средний чек':float(r[4])} for r in cur.fetchall()]
        cur.execute(sql.SQL('SELECT sum(revenue)/sum(orders) FROM {}.v_sales').format(sql.Identifier(schema)))
        avg=float(cur.fetchone()[0])
    assert avg==80
    cfg['schema']=schema
    config_path=tmp_path/'config.json'
    config_path.write_text(json.dumps(cfg,ensure_ascii=False),encoding='utf-8')
    monkeypatch.setattr(sys,'argv',['build','--config',str(config_path)])
    build.main()
    assert len(fake_superset.S.ch)==6
    data={'values':{'bn_revenue':400,'bn_orders':5},'rows':{'table_region':rows,'top_region':rows,'bar_rev_year':[{'year':2025,'Выручка':400}],'line_avg_year':[{'year':2025,'Средний чек':avg}]}}
    page=render_html.render(cfg,data)
    out=tmp_path/'sql-e2e.html'
    out.write_text(page,encoding='utf-8')
    assert '>400<' in page and 'Москва' in page and '80.0' in page
