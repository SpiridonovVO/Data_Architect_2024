import os
from pathlib import Path
import subprocess
import sys
from unittest.mock import Mock

import pytest

from conftest import TEMPLATES

def connection():
    cn=Mock()
    cur=Mock()
    cur.__enter__=Mock(return_value=cur)
    cur.__exit__=Mock(return_value=False)
    cn.cursor.return_value=cur
    return cn,cur

@pytest.mark.parametrize('method',['FULL','INC','DELTA','APPEND','UPSERT','PARTREPL','SNAPSHOT'])
def test_all_load_methods_dispatch(loader,monkeypatch,method):
    cn,cur=connection()
    monkeypatch.setattr(loader,'LOAD_METHOD',method)
    monkeypatch.setenv('PARTITION','2025-01')
    rows=[('1','2025-01-01','{}')]
    if method=='PARTREPL':
        monkeypatch.setattr(loader,'COLUMNS',['id','updated_at','payload','partition_key'])
        rows=[('1','2025-01-01','{}','2025-01')]
    insert=Mock()
    monkeypatch.setattr(loader,'execute_values',insert)
    assert loader.load(cn,rows)==1
    insert.assert_called_once()
    cn.commit.assert_called_once()
    if method in ('INC','UPSERT','DELTA','SNAPSHOT'):
        assert 'ON CONFLICT' in insert.call_args.args[1]
    if method=='FULL':
        assert 'TRUNCATE' in cur.execute.call_args.args[0]
    if method=='PARTREPL':
        assert cur.execute.call_args.args[1]==('2025-01',)

@pytest.mark.parametrize('method',['FULL','INC','DELTA','APPEND','UPSERT','PARTREPL','SNAPSHOT'])
def test_empty_source_does_not_truncate(loader,monkeypatch,method):
    cn,cur=connection()
    monkeypatch.setattr(loader,'LOAD_METHOD',method)
    insert=Mock()
    monkeypatch.setattr(loader,'execute_values',insert)
    assert loader.load(cn,[])==0
    cur.execute.assert_not_called()
    insert.assert_not_called()

def test_allow_empty_full_explicit(loader,monkeypatch):
    cn,cur=connection()
    monkeypatch.setattr(loader,'LOAD_METHOD','FULL')
    monkeypatch.setenv('ALLOW_EMPTY_FULL','1')
    assert loader.load(cn,[])==0
    assert 'TRUNCATE' in cur.execute.call_args.args[0]

def test_unknown_method_rejected(loader,monkeypatch):
    cn,cur=connection()
    monkeypatch.setattr(loader,'LOAD_METHOD','BOGUS')
    with pytest.raises(ValueError):
        loader.load(cn,[(1,)])
    cn.commit.assert_not_called()

def test_partition_required(loader,monkeypatch):
    cn,cur=connection()
    monkeypatch.setattr(loader,'LOAD_METHOD','PARTREPL')
    with pytest.raises(ValueError,match='PARTITION'):
        loader.load(cn,[(1,)])

def test_partition_requires_key_column(loader,monkeypatch):
    cn,cur=connection()
    monkeypatch.setattr(loader,'LOAD_METHOD','PARTREPL')
    monkeypatch.setenv('PARTITION','2025-01')
    with pytest.raises(ValueError,match='partition_key'):
        loader.load(cn,[('1','2025-01-01','{}')])

def test_partition_rows_must_match_partition(loader,monkeypatch):
    cn,cur=connection()
    monkeypatch.setattr(loader,'LOAD_METHOD','PARTREPL')
    monkeypatch.setattr(loader,'COLUMNS',['id','updated_at','payload','partition_key'])
    monkeypatch.setenv('PARTITION','2025-01')
    with pytest.raises(ValueError,match='соответствовать'):
        loader.load(cn,[('1','2025-02-01','{}','2025-02')])

def test_retry_recovers(loader,monkeypatch):
    sleep=Mock()
    monkeypatch.setattr(loader.time,'sleep',sleep)
    fn=Mock(side_effect=[ConnectionError('transient'),ConnectionError('transient'),42])
    assert loader.retry(fn)==42
    assert fn.call_count==3 and [c.args[0] for c in sleep.call_args_list]==[1,2]

def test_retry_exhaustion(loader,monkeypatch):
    monkeypatch.setattr(loader,'MAX_RETRIES',3)
    monkeypatch.setattr(loader.time,'sleep',Mock())
    fn=Mock(side_effect=ConnectionError('transient'))
    with pytest.raises(ConnectionError):
        loader.retry(fn)
    assert fn.call_count==3

def test_retry_zero_rejected(loader,monkeypatch):
    monkeypatch.setattr(loader,'MAX_RETRIES',0)
    with pytest.raises(ValueError):
        loader.retry(lambda:42)

def test_upsert_only_key_uses_do_nothing(loader,monkeypatch):
    monkeypatch.setattr(loader,'COLUMNS',['id'])
    monkeypatch.setattr(loader,'KEY_COLS',['id'])
    assert 'DO NOTHING' in loader._upsert_sql('qa.fact')

def test_upsert_updates_freshness(loader):
    assert 'loaded_at=now()' in loader._upsert_sql('qa.fact')

def test_snapshot_column_must_not_duplicate(loader,monkeypatch):
    monkeypatch.setattr(loader,'LOAD_METHOD','SNAPSHOT')
    monkeypatch.setattr(loader,'COLUMNS',['id','updated_at','payload','snapshot_date'])
    monkeypatch.setattr(loader,'KEY_COLS',['id','snapshot_date'])
    cn,cur=connection()
    insert=Mock()
    monkeypatch.setattr(loader,'execute_values',insert)
    loader.load(cn,[('1','2025-01-01','{}','2025-01-01')])
    columns=insert.call_args.args[1].split('(',1)[1].split(')',1)[0].split(',')
    assert len(columns)==len(set(columns)), 'snapshot_date duplicated in INSERT columns'

def test_extract_placeholder_fails_closed(loader):
    with pytest.raises(NotImplementedError):
        loader.extract('watermark')

def test_loader_failure_rolls_back_closes(loader,monkeypatch):
    cn,cur=connection()
    monkeypatch.setattr(loader,'connect',lambda:cn)
    monkeypatch.setattr(loader,'ensure_schema_table',lambda cn:None)
    monkeypatch.setattr(loader,'read_cursor',lambda cn:None)
    monkeypatch.setattr(loader,'extract',lambda c:([('1',)],'new'))
    monkeypatch.setattr(loader,'load',Mock(side_effect=RuntimeError('insert failed')))
    with pytest.raises(RuntimeError):
        loader.main()
    cn.rollback.assert_called_once()
    cn.close.assert_called_once()

def test_loader_success_saves_watermark_closes(loader,monkeypatch):
    cn,cur=connection()
    monkeypatch.setattr(loader,'connect',lambda:cn)
    monkeypatch.setattr(loader,'ensure_schema_table',lambda cn:None)
    monkeypatch.setattr(loader,'read_cursor',lambda cn:'old')
    extract=Mock(return_value=([('1',)],'new'))
    monkeypatch.setattr(loader,'extract',extract)
    monkeypatch.setattr(loader,'load',lambda cn,rows,commit=True:1)
    save=Mock()
    monkeypatch.setattr(loader,'save_cursor',save)
    loader.main()
    extract.assert_called_once_with('old')
    save.assert_called_once_with(cn,'new',commit=False)
    cn.close.assert_called_once()

def test_missing_key_guard_subprocess():
    env=dict(os.environ,KEY_COLS='not_a_column',COLUMNS='id',PYTHONIOENCODING='utf-8')
    r=subprocess.run([sys.executable,str(TEMPLATES/'loader.py')],env=env,capture_output=True,text=True,encoding='utf-8')
    assert r.returncode!=0 and 'KEY_COLS' in r.stderr

@pytest.mark.parametrize('value',['a.b','a;DROP','x--','', 'x\n'])
def test_loader_identifier_strict(loader,value):
    with pytest.raises(ValueError):
        loader._ident(value)

@pytest.mark.parametrize('value',['a.b','a;DROP','x--','','x\n'])
def test_runtime_identifiers_reject_invalid(loader,value):
    with pytest.raises(ValueError):
        loader._ident(value)

def test_source_adapter_is_explicit_template(loader):
    assert 'извлечение' in loader.extract.__doc__
